import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, integer, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const userRoleEnum = pgEnum('user_role', ['user', 'admin']);
export const transactionTypeEnum = pgEnum('transaction_type', ['deposit', 'card_generation', 'top_up', 'fee']);
export const transactionStatusEnum = pgEnum('transaction_status', ['pending', 'completed', 'rejected']);
export const depositStatusEnum = pgEnum('deposit_status', ['pending', 'approved', 'rejected']);
export const cardStatusEnum = pgEnum('card_status', ['active', 'locked', 'expired']);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").default('user').notNull(),
  balance: decimal("balance", { precision: 10, scale: 2 }).default('0.00').notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const deposits = pgTable("deposits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  amount: decimal("amount", { precision: 10, scale: 4 }).notNull(),
  exactAmount: decimal("exact_amount", { precision: 10, scale: 4 }).notNull(), // with random decimals
  txHash: text("tx_hash"),
  status: depositStatusEnum("status").default('pending').notNull(),
  walletAddress: text("wallet_address").notNull().default('0x463f5d4c8a62403a0a28a60712347ae215dab39c'),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const virtualCards = pgTable("virtual_cards", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  cardNumber: text("card_number").notNull(),
  expiryMonth: text("expiry_month").notNull(),
  expiryYear: text("expiry_year").notNull(),
  cvv: text("cvv").notNull(),
  cardType: text("card_type").notNull(), // visa, mastercard, etc
  balance: decimal("balance", { precision: 10, scale: 2 }).default('0.00').notNull(),
  status: cardStatusEnum("status").default('active').notNull(),
  apiCardId: text("api_card_id"), // ID from GPay Card API
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  type: transactionTypeEnum("type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: transactionStatusEnum("status").default('pending').notNull(),
  description: text("description"),
  cardId: varchar("card_id").references(() => virtualCards.id, { onDelete: 'set null' }),
  depositId: varchar("deposit_id").references(() => deposits.id, { onDelete: 'set null' }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  deposits: many(deposits),
  virtualCards: many(virtualCards),
  transactions: many(transactions),
}));

export const depositsRelations = relations(deposits, ({ one, many }) => ({
  user: one(users, {
    fields: [deposits.userId],
    references: [users.id],
  }),
  transactions: many(transactions),
}));

export const virtualCardsRelations = relations(virtualCards, ({ one, many }) => ({
  user: one(users, {
    fields: [virtualCards.userId],
    references: [users.id],
  }),
  transactions: many(transactions),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
  card: one(virtualCards, {
    fields: [transactions.cardId],
    references: [virtualCards.id],
  }),
  deposit: one(deposits, {
    fields: [transactions.depositId],
    references: [deposits.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDepositSchema = createInsertSchema(deposits).pick({
  amount: true,
  exactAmount: true,
  txHash: true,
});

export const insertVirtualCardSchema = createInsertSchema(virtualCards).pick({
  cardNumber: true,
  expiryMonth: true,
  expiryYear: true,
  cvv: true,
  cardType: true,
  balance: true,
  apiCardId: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  type: true,
  amount: true,
  status: true,
  description: true,
  cardId: true,
  depositId: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDeposit = z.infer<typeof insertDepositSchema>;
export type Deposit = typeof deposits.$inferSelect;
export type InsertVirtualCard = z.infer<typeof insertVirtualCardSchema>;
export type VirtualCard = typeof virtualCards.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
