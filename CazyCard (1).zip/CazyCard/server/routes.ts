import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, requireAuth, requireAdmin } from "./auth";
import { insertDepositSchema, insertVirtualCardSchema, insertTransactionSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);

  // Deposit routes
  app.post("/api/deposits", requireAuth, async (req: any, res) => {
    try {
      const { amount } = req.body;
      
      // Generate random 4-digit decimal
      const randomDecimal = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
      const exactAmount = `${amount}.${randomDecimal}`;
      
      const deposit = await storage.createDeposit({
        userId: req.user.id,
        amount: amount.toString(),
        exactAmount,
      });

      // Create transaction record
      await storage.createTransaction({
        userId: req.user.id,
        type: 'deposit',
        amount: amount.toString(),
        status: 'pending',
        description: `Deposit request - $${exactAmount}`,
        depositId: deposit.id,
      });

      res.json({ deposit, exactAmount });
    } catch (error) {
      console.error("Deposit creation error:", error);
      res.status(500).json({ message: "Failed to create deposit" });
    }
  });

  app.get("/api/deposits", requireAuth, async (req: any, res) => {
    try {
      const deposits = await storage.getUserDeposits(req.user.id);
      res.json(deposits);
    } catch (error) {
      console.error("Get deposits error:", error);
      res.status(500).json({ message: "Failed to fetch deposits" });
    }
  });

  // Virtual card routes
  app.post("/api/cards", requireAuth, async (req: any, res) => {
    try {
      const { cardType, loadAmount } = req.body;
      
      // Check user balance
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const currentBalance = parseFloat(user.balance);
      const cardFee = 2.00;
      const loadFee = parseFloat(loadAmount) * 0.03;
      const totalCost = cardFee + loadFee + parseFloat(loadAmount);

      if (currentBalance < totalCost) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Call GPay Card API
      const apiKey = process.env.GPAY_CARD_API_KEY || 'zJZPahQIQuKZQARlxCigLw==';
      
      try {
        // Mock card generation for now - replace with actual API call
        const mockCard = {
          cardNumber: `4${Math.floor(Math.random() * 1000000000000000).toString().padStart(15, '0')}`,
          expiryMonth: '12',
          expiryYear: '27',
          cvv: Math.floor(Math.random() * 900 + 100).toString(),
          cardType: cardType.toLowerCase(),
          balance: loadAmount.toString(),
          apiCardId: `gp_${Math.random().toString(36).substr(2, 9)}`,
        };

        // Create card in database
        const card = await storage.createVirtualCard({
          userId: req.user.id,
          ...mockCard,
        });

        // Update user balance
        const newBalance = (currentBalance - totalCost).toFixed(2);
        await storage.updateUserBalance(req.user.id, newBalance);

        // Create transaction records
        await storage.createTransaction({
          userId: req.user.id,
          type: 'card_generation',
          amount: (-totalCost).toString(),
          status: 'completed',
          description: `Card generation - ${cardType} ${card.cardNumber.slice(-4)}`,
          cardId: card.id,
        });

        res.json(card);
      } catch (apiError) {
        console.error("GPay Card API error:", apiError);
        res.status(500).json({ message: "Failed to generate card through API" });
      }
    } catch (error) {
      console.error("Card generation error:", error);
      res.status(500).json({ message: "Failed to generate card" });
    }
  });

  app.get("/api/cards", requireAuth, async (req: any, res) => {
    try {
      const cards = await storage.getUserCards(req.user.id);
      res.json(cards);
    } catch (error) {
      console.error("Get cards error:", error);
      res.status(500).json({ message: "Failed to fetch cards" });
    }
  });

  app.patch("/api/cards/:id/balance", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { amount } = req.body;
      
      const card = await storage.getCardById(id);
      if (!card || card.userId !== req.user.id) {
        return res.status(404).json({ message: "Card not found" });
      }

      // Check user balance
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const currentBalance = parseFloat(user.balance);
      if (currentBalance < parseFloat(amount)) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Update card balance
      const newCardBalance = (parseFloat(card.balance) + parseFloat(amount)).toFixed(2);
      await storage.updateCardBalance(id, newCardBalance);

      // Update user balance
      const newUserBalance = (currentBalance - parseFloat(amount)).toFixed(2);
      await storage.updateUserBalance(req.user.id, newUserBalance);

      // Create transaction
      await storage.createTransaction({
        userId: req.user.id,
        type: 'top_up',
        amount: (-parseFloat(amount)).toString(),
        status: 'completed',
        description: `Top up card ${card.cardNumber.slice(-4)}`,
        cardId: id,
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Card top-up error:", error);
      res.status(500).json({ message: "Failed to top up card" });
    }
  });

  app.patch("/api/cards/:id/status", requireAuth, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      const card = await storage.getCardById(id);
      if (!card || card.userId !== req.user.id) {
        return res.status(404).json({ message: "Card not found" });
      }

      await storage.updateCardStatus(id, status);
      res.json({ success: true });
    } catch (error) {
      console.error("Card status update error:", error);
      res.status(500).json({ message: "Failed to update card status" });
    }
  });

  // Transaction routes
  app.get("/api/transactions", requireAuth, async (req: any, res) => {
    try {
      const transactions = await storage.getUserTransactions(req.user.id);
      res.json(transactions);
    } catch (error) {
      console.error("Get transactions error:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Admin routes
  app.get("/api/admin/users", requireAdmin, async (req: any, res) => {
    try {
      const { search } = req.query;
      const users = search 
        ? await storage.searchUsers(search as string)
        : await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Admin get users error:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/admin/users/:id/balance", requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { amount, action } = req.body; // action: 'add' or 'subtract'
      
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const currentBalance = parseFloat(user.balance);
      const changeAmount = parseFloat(amount);
      const newBalance = action === 'add' 
        ? (currentBalance + changeAmount).toFixed(2)
        : (currentBalance - changeAmount).toFixed(2);

      if (parseFloat(newBalance) < 0) {
        return res.status(400).json({ message: "Balance cannot be negative" });
      }

      await storage.updateUserBalance(id, newBalance);

      // Create transaction record
      await storage.createTransaction({
        userId: id,
        type: 'fee',
        amount: action === 'add' ? changeAmount.toString() : (-changeAmount).toString(),
        status: 'completed',
        description: `Admin balance ${action} - $${amount}`,
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Admin balance adjustment error:", error);
      res.status(500).json({ message: "Failed to adjust balance" });
    }
  });

  app.get("/api/admin/deposits", requireAdmin, async (req: any, res) => {
    try {
      const deposits = await storage.getPendingDeposits();
      res.json(deposits);
    } catch (error) {
      console.error("Admin get deposits error:", error);
      res.status(500).json({ message: "Failed to fetch deposits" });
    }
  });

  app.patch("/api/admin/deposits/:id", requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { status, txHash } = req.body;
      
      const deposit = await storage.getDepositById(id);
      if (!deposit) {
        return res.status(404).json({ message: "Deposit not found" });
      }

      await storage.updateDepositStatus(id, status, txHash);

      if (status === 'approved') {
        // Update user balance
        const user = await storage.getUser(deposit.userId);
        if (user) {
          const currentBalance = parseFloat(user.balance);
          const depositAmount = parseFloat(deposit.amount);
          const newBalance = (currentBalance + depositAmount).toFixed(2);
          await storage.updateUserBalance(deposit.userId, newBalance);

          // Update transaction status
          await storage.createTransaction({
            userId: deposit.userId,
            type: 'deposit',
            amount: deposit.amount,
            status: 'completed',
            description: `Deposit approved - $${deposit.amount}`,
            depositId: id,
          });
        }
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Admin deposit approval error:", error);
      res.status(500).json({ message: "Failed to process deposit" });
    }
  });

  app.get("/api/admin/cards", requireAdmin, async (req: any, res) => {
    try {
      const cards = await storage.getAllCards();
      res.json(cards);
    } catch (error) {
      console.error("Admin get cards error:", error);
      res.status(500).json({ message: "Failed to fetch cards" });
    }
  });

  app.get("/api/admin/transactions", requireAdmin, async (req: any, res) => {
    try {
      const transactions = await storage.getAllTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Admin get transactions error:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.get("/api/admin/stats", requireAdmin, async (req: any, res) => {
    try {
      const [users, cards, transactions] = await Promise.all([
        storage.getAllUsers(),
        storage.getAllCards(),
        storage.getAllTransactions(),
      ]);

      const pendingDeposits = await storage.getPendingDeposits();
      
      const totalVolume = transactions
        .filter(t => t.type === 'deposit' && t.status === 'completed')
        .reduce((sum, t) => sum + parseFloat(t.amount), 0);

      res.json({
        totalUsers: users.length,
        totalCards: cards.length,
        totalVolume: totalVolume.toFixed(2),
        pendingDeposits: pendingDeposits.length,
      });
    } catch (error) {
      console.error("Admin stats error:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
