import { 
  users, 
  deposits, 
  virtualCards, 
  transactions,
  type User, 
  type InsertUser,
  type Deposit,
  type InsertDeposit,
  type VirtualCard,
  type InsertVirtualCard,
  type Transaction,
  type InsertTransaction
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, like } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: string, newBalance: string): Promise<void>;
  
  // Deposit operations
  createDeposit(deposit: InsertDeposit & { userId: string }): Promise<Deposit>;
  getDepositById(id: string): Promise<Deposit | undefined>;
  getPendingDeposits(): Promise<Deposit[]>;
  updateDepositStatus(id: string, status: 'approved' | 'rejected', txHash?: string): Promise<void>;
  getUserDeposits(userId: string): Promise<Deposit[]>;
  
  // Virtual card operations
  createVirtualCard(card: InsertVirtualCard & { userId: string }): Promise<VirtualCard>;
  getUserCards(userId: string): Promise<VirtualCard[]>;
  getCardById(id: string): Promise<VirtualCard | undefined>;
  updateCardBalance(cardId: string, newBalance: string): Promise<void>;
  updateCardStatus(cardId: string, status: 'active' | 'locked' | 'expired'): Promise<void>;
  getAllCards(): Promise<VirtualCard[]>;
  
  // Transaction operations
  createTransaction(transaction: InsertTransaction & { userId: string }): Promise<Transaction>;
  getUserTransactions(userId: string): Promise<Transaction[]>;
  getAllTransactions(): Promise<Transaction[]>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  searchUsers(query: string): Promise<User[]>;
  
  // Session store
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, newBalance: string): Promise<void> {
    await db
      .update(users)
      .set({ balance: newBalance, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  // Deposit operations
  async createDeposit(deposit: InsertDeposit & { userId: string }): Promise<Deposit> {
    const [newDeposit] = await db
      .insert(deposits)
      .values(deposit)
      .returning();
    return newDeposit;
  }

  async getDepositById(id: string): Promise<Deposit | undefined> {
    const [deposit] = await db.select().from(deposits).where(eq(deposits.id, id));
    return deposit || undefined;
  }

  async getPendingDeposits(): Promise<Deposit[]> {
    return await db
      .select()
      .from(deposits)
      .where(eq(deposits.status, 'pending'))
      .orderBy(desc(deposits.createdAt));
  }

  async updateDepositStatus(id: string, status: 'approved' | 'rejected', txHash?: string): Promise<void> {
    const updateData: any = { status, updatedAt: new Date() };
    if (txHash) updateData.txHash = txHash;
    
    await db
      .update(deposits)
      .set(updateData)
      .where(eq(deposits.id, id));
  }

  async getUserDeposits(userId: string): Promise<Deposit[]> {
    return await db
      .select()
      .from(deposits)
      .where(eq(deposits.userId, userId))
      .orderBy(desc(deposits.createdAt));
  }

  // Virtual card operations
  async createVirtualCard(card: InsertVirtualCard & { userId: string }): Promise<VirtualCard> {
    const [newCard] = await db
      .insert(virtualCards)
      .values(card)
      .returning();
    return newCard;
  }

  async getUserCards(userId: string): Promise<VirtualCard[]> {
    return await db
      .select()
      .from(virtualCards)
      .where(eq(virtualCards.userId, userId))
      .orderBy(desc(virtualCards.createdAt));
  }

  async getCardById(id: string): Promise<VirtualCard | undefined> {
    const [card] = await db.select().from(virtualCards).where(eq(virtualCards.id, id));
    return card || undefined;
  }

  async updateCardBalance(cardId: string, newBalance: string): Promise<void> {
    await db
      .update(virtualCards)
      .set({ balance: newBalance, updatedAt: new Date() })
      .where(eq(virtualCards.id, cardId));
  }

  async updateCardStatus(cardId: string, status: 'active' | 'locked' | 'expired'): Promise<void> {
    await db
      .update(virtualCards)
      .set({ status, updatedAt: new Date() })
      .where(eq(virtualCards.id, cardId));
  }

  async getAllCards(): Promise<VirtualCard[]> {
    return await db
      .select()
      .from(virtualCards)
      .orderBy(desc(virtualCards.createdAt));
  }

  // Transaction operations
  async createTransaction(transaction: InsertTransaction & { userId: string }): Promise<Transaction> {
    const [newTransaction] = await db
      .insert(transactions)
      .values(transaction)
      .returning();
    return newTransaction;
  }

  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .orderBy(desc(transactions.createdAt));
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .orderBy(desc(users.createdAt));
  }

  async searchUsers(query: string): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(like(users.username, `%${query}%`))
      .orderBy(desc(users.createdAt));
  }
}

export const storage = new DatabaseStorage();
