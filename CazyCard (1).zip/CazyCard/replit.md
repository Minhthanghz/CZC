# CazyCard Virtual Card Management System

## Overview

CazyCard is a modern web application for virtual card generation and management, inspired by bingcard.com. The platform allows users to create virtual credit cards, manage deposits via USDT (BEP-20), and handle transactions. The system features a cyberpunk-inspired dark theme with blue and yellow accent colors, providing both user and admin functionality.

The application integrates with the GPay Card API for virtual card generation and supports role-based access control with user and admin roles. Users can deposit funds, generate cards, manage balances, and view transaction history, while admins have additional oversight capabilities for managing the entire platform.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom cyberpunk theme using blue/yellow color scheme
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and data fetching
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules
- **Authentication**: Passport.js with local strategy and session-based auth
- **Session Storage**: PostgreSQL-backed session store using connect-pg-simple
- **Password Security**: Node.js crypto module with scrypt hashing

### Database Architecture
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Comprehensive schema with users, deposits, virtual cards, and transactions
- **Migrations**: Drizzle Kit for database schema management

### Key Data Models
- **Users**: Username/password auth with role-based permissions (user/admin)
- **Deposits**: USDT-BEP20 deposits with exact amount generation and approval workflow
- **Virtual Cards**: Generated via API with card details, balance tracking, and status management
- **Transactions**: Comprehensive transaction logging for all financial operations

### Authentication & Authorization
- **Session-based authentication** with secure password hashing
- **Role-based access control** supporting user and admin roles
- **Protected routes** with automatic redirection based on authentication status
- **Default admin account**: username: admin, password: admin123

### API Integration
- **GPay Card API**: External service for virtual card generation
- **API Endpoint**: https://web.gpaycard.world/api_document
- **API Key**: zJZPahQIQuKZQARlxCigLw==

### UI/UX Design
- **Theme**: Dark mode cyberpunk aesthetic with neon accents
- **Color Palette**: Primary blue (#3B82F6), accent yellow (#F59E0B), dark backgrounds
- **Layout**: Responsive design with mobile-first approach
- **Components**: Reusable component library based on Radix UI primitives

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection for Neon hosting
- **drizzle-orm & drizzle-kit**: Type-safe ORM and migration tools
- **@tanstack/react-query**: Server state management and data fetching
- **passport & passport-local**: Authentication middleware and local strategy
- **express-session & connect-pg-simple**: Session management with PostgreSQL storage

### UI Dependencies
- **@radix-ui/***: Comprehensive set of unstyled, accessible UI primitives
- **class-variance-authority & clsx**: Utility-first styling and conditional classes
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **react-hook-form & @hookform/resolvers**: Form state management and validation
- **zod & drizzle-zod**: Runtime type validation and schema validation

### Development Tools
- **vite**: Fast build tool and development server
- **typescript**: Static type checking and enhanced developer experience
- **@replit/vite-plugin-***: Replit-specific development enhancements
- **esbuild**: Fast JavaScript bundler for production builds

### External Services
- **GPay Card API**: Third-party virtual card generation service
- **Neon Database**: Serverless PostgreSQL hosting platform
- **USDT-BEP20**: Cryptocurrency payment method for deposits

### Utility Libraries
- **date-fns**: Modern date utility library for JavaScript
- **crypto (Node.js)**: Built-in cryptographic functionality for password hashing
- **ws**: WebSocket library for database connections