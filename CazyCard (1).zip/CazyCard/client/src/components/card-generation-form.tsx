import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export function CardGenerationForm() {
  const { user } = useAuth();
  const [cardType, setCardType] = useState("visa");
  const [loadAmount, setLoadAmount] = useState("");
  const { toast } = useToast();

  const balance = parseFloat(user?.balance || '0');
  const cardFee = 2.00;
  const loadFee = parseFloat(loadAmount || '0') * 0.03;
  const totalCost = cardFee + loadFee + parseFloat(loadAmount || '0');

  const generateCardMutation = useMutation({
    mutationFn: async (data: { cardType: string; loadAmount: string }) => {
      const res = await apiRequest("POST", "/api/cards", data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Card Generated Successfully",
        description: `Your ${cardType.toUpperCase()} card ending in ${data.cardNumber.slice(-4)} is ready to use!`,
      });
      setLoadAmount("");
    },
    onError: (error: Error) => {
      toast({
        title: "Card Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!loadAmount || parseFloat(loadAmount) < 10) {
      toast({
        title: "Invalid Amount",
        description: "Minimum load amount is $10",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(loadAmount) > 1000) {
      toast({
        title: "Invalid Amount",
        description: "Maximum load amount is $1,000",
        variant: "destructive",
      });
      return;
    }

    if (balance < totalCost) {
      toast({
        title: "Insufficient Balance",
        description: `You need $${totalCost.toFixed(2)} but only have $${balance.toFixed(2)}`,
        variant: "destructive",
      });
      return;
    }

    generateCardMutation.mutate({ cardType, loadAmount });
  };

  return (
    <div className="max-w-2xl" data-testid="card-generation-form">
      <Card className="glass-card" data-testid="card-form">
        <CardHeader>
          <CardTitle data-testid="text-form-title">Generate New Virtual Card</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="cardType" data-testid="label-card-type">Card Type</Label>
              <Select value={cardType} onValueChange={setCardType}>
                <SelectTrigger className="bg-input border-border" data-testid="select-card-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="visa">Visa</SelectItem>
                  <SelectItem value="mastercard">Mastercard</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="loadAmount" data-testid="label-load-amount">Load Amount (USD)</Label>
              <Input
                id="loadAmount"
                type="number"
                step="0.01"
                min="10"
                max="1000"
                placeholder="Enter amount"
                value={loadAmount}
                onChange={(e) => setLoadAmount(e.target.value)}
                className="bg-input border-border"
                data-testid="input-load-amount"
              />
              <p className="text-sm text-muted-foreground mt-1" data-testid="text-amount-hint">
                Minimum: $10, Maximum: $1,000
              </p>
            </div>
            
            {/* Fee Summary */}
            <Card className="bg-muted/50 border-border" data-testid="card-fee-summary">
              <CardContent className="p-4">
                <h4 className="font-medium mb-3" data-testid="text-fee-summary-title">Fee Summary</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span data-testid="text-card-generation-fee-label">Card Generation Fee:</span>
                    <span data-testid="text-card-generation-fee">${cardFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span data-testid="text-load-fee-label">Load Fee (3%):</span>
                    <span data-testid="text-load-fee">${loadFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span data-testid="text-load-amount-label">Load Amount:</span>
                    <span data-testid="text-load-amount-value">${parseFloat(loadAmount || '0').toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-medium text-base">
                    <span data-testid="text-total-cost-label">Total Cost:</span>
                    <span className={totalCost > balance ? "text-destructive" : "text-primary"} data-testid="text-total-cost">
                      ${totalCost.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span data-testid="text-current-balance-label">Current Balance:</span>
                    <span data-testid="text-current-balance">${balance.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-primary to-accent text-primary-foreground font-semibold cyber-glow"
              disabled={!loadAmount || generateCardMutation.isPending || balance < totalCost}
              data-testid="button-generate-card"
            >
              {generateCardMutation.isPending 
                ? "Generating Card..." 
                : balance < totalCost 
                ? "Insufficient Balance"
                : "Generate Card"
              }
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
