import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface DepositModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const DEPOSIT_AMOUNTS = [50, 100, 200, 500, 1000, 5000];
const WALLET_ADDRESS = "0x463f5d4c8a62403a0a28a60712347ae215dab39c";

export function DepositModal({ open, onOpenChange }: DepositModalProps) {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [exactAmount, setExactAmount] = useState<string>("");
  const { toast } = useToast();

  const createDepositMutation = useMutation({
    mutationFn: async (amount: number) => {
      const res = await apiRequest("POST", "/api/deposits", { amount });
      return await res.json();
    },
    onSuccess: (data) => {
      setExactAmount(data.exactAmount);
      queryClient.invalidateQueries({ queryKey: ["/api/deposits"] });
      toast({
        title: "Deposit Request Created",
        description: `Send exactly ${data.exactAmount} USDT to the provided address`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSelectAmount = (amount: number) => {
    setSelectedAmount(amount);
    createDepositMutation.mutate(amount);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied",
        description: "Address copied to clipboard",
      });
    });
  };

  const handleClose = () => {
    setSelectedAmount(null);
    setExactAmount("");
    onOpenChange(false);
  };

  const confirmPayment = () => {
    toast({
      title: "Payment Recorded",
      description: "Your deposit will be reviewed and approved by an admin shortly.",
    });
    handleClose();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card max-w-md" data-testid="deposit-modal">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl font-bold neon-text" data-testid="text-deposit-modal-title">
              Make Deposit
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              data-testid="button-close-deposit-modal"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-6">
          {!selectedAmount ? (
            <>
              {/* Amount Selection */}
              <div data-testid="deposit-amount-selection">
                <label className="block text-sm font-medium mb-3" data-testid="label-select-amount">
                  Select Deposit Amount
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {DEPOSIT_AMOUNTS.map((amount) => (
                    <Button
                      key={amount}
                      variant="outline"
                      className="cyber-border hover:bg-primary/20 hover:border-primary transition-colors"
                      onClick={() => handleSelectAmount(amount)}
                      disabled={createDepositMutation.isPending}
                      data-testid={`button-amount-${amount}`}
                    >
                      ${amount}
                    </Button>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Deposit Instructions */}
              <div data-testid="deposit-instructions">
                <Card className="bg-accent/10 border-accent/30" data-testid="card-deposit-instructions">
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-accent mb-2" data-testid="text-instructions-title">
                      Deposit Instructions
                    </h4>
                    <div className="space-y-3 text-sm">
                      <div>
                        <p className="font-medium mb-1" data-testid="text-wallet-address-label">
                          Wallet Address:
                        </p>
                        <div className="flex items-center space-x-2 bg-background p-2 rounded border">
                          <code className="flex-1 font-mono text-xs break-all" data-testid="text-wallet-address">
                            {WALLET_ADDRESS}
                          </code>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(WALLET_ADDRESS)}
                            data-testid="button-copy-address"
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      
                      {exactAmount && (
                        <div>
                          <p className="font-medium mb-1" data-testid="text-exact-amount-label">
                            Exact Amount to Send:
                          </p>
                          <div className="flex items-center space-x-2">
                            <Badge className="text-lg font-bold bg-primary text-primary-foreground" data-testid="badge-exact-amount">
                              {exactAmount} USDT
                            </Badge>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyToClipboard(exactAmount)}
                              data-testid="button-copy-amount"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      )}
                      
                      <p className="text-muted-foreground" data-testid="text-deposit-warning">
                        ⚠️ Send exactly this amount for automatic tracking. Admin will verify and approve your deposit.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Button
                className="w-full cyber-glow"
                onClick={confirmPayment}
                data-testid="button-confirm-payment"
              >
                I've Sent the Payment
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
