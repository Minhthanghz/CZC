import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Eye, EyeOff, Plus, Lock, Unlock, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface VirtualCardProps {
  card: any;
  showDetails: boolean;
  onToggleDetails: () => void;
}

export function VirtualCard({ card, showDetails, onToggleDetails }: VirtualCardProps) {
  const [topUpAmount, setTopUpAmount] = useState("");
  const { toast } = useToast();

  const topUpMutation = useMutation({
    mutationFn: async (amount: string) => {
      await apiRequest("PATCH", `/api/cards/${card.id}/balance`, { amount });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Card Topped Up",
        description: `Successfully added $${topUpAmount} to your card`,
      });
      setTopUpAmount("");
    },
    onError: (error: Error) => {
      toast({
        title: "Top-up Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const toggleStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      await apiRequest("PATCH", `/api/cards/${card.id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      toast({
        title: "Card Status Updated",
        description: `Card has been ${card.status === 'active' ? 'locked' : 'unlocked'}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Status Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getCardGradient = () => {
    switch (card.cardType.toLowerCase()) {
      case 'visa':
        return 'bg-gradient-to-r from-primary to-accent';
      case 'mastercard':
        return 'bg-gradient-to-r from-slate-800 to-slate-600';
      default:
        return 'bg-gradient-to-r from-primary to-accent';
    }
  };

  const formatCardNumber = (number: string) => {
    if (showDetails) {
      return number.replace(/(.{4})/g, '$1 ').trim();
    }
    return `**** **** **** ${number.slice(-4)}`;
  };

  const handleTopUp = () => {
    if (!topUpAmount || parseFloat(topUpAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid top-up amount",
        variant: "destructive",
      });
      return;
    }
    topUpMutation.mutate(topUpAmount);
  };

  const handleToggleStatus = () => {
    const newStatus = card.status === 'active' ? 'locked' : 'active';
    toggleStatusMutation.mutate(newStatus);
  };

  return (
    <Card className="glass-card" data-testid={`virtual-card-${card.id}`}>
      <CardContent className="p-6">
        {/* Card Visual */}
        <div className={`${getCardGradient()} p-4 rounded-lg text-primary-foreground mb-4`} data-testid={`card-visual-${card.id}`}>
          <div className="flex justify-between items-start mb-8">
            <div>
              <p className="text-sm font-medium" data-testid={`text-card-brand-${card.id}`}>Virtual Card</p>
              <p className="text-xs" data-testid={`text-card-issuer-${card.id}`}>CazyCard</p>
            </div>
            <div className="text-2xl font-bold" data-testid={`icon-card-type-${card.id}`}>
              {card.cardType.toLowerCase() === 'visa' ? 'VISA' : 'MC'}
            </div>
          </div>
          
          <div className="font-mono text-lg mb-4" data-testid={`text-card-number-${card.id}`}>
            {formatCardNumber(card.cardNumber)}
          </div>
          
          <div className="flex justify-between text-sm">
            <div>
              <p className="text-xs opacity-75" data-testid={`label-expiry-${card.id}`}>VALID THRU</p>
              <p className="font-medium" data-testid={`text-expiry-${card.id}`}>
                {showDetails ? `${card.expiryMonth}/${card.expiryYear}` : '**/**'}
              </p>
            </div>
            <div>
              <p className="text-xs opacity-75" data-testid={`label-cvv-${card.id}`}>CVV</p>
              <p className="font-medium" data-testid={`text-cvv-${card.id}`}>
                {showDetails ? card.cvv : '***'}
              </p>
            </div>
          </div>
        </div>

        {/* Card Details */}
        <div className="space-y-2 mb-4">
          <div className="flex justify-between">
            <span className="text-muted-foreground" data-testid={`label-balance-${card.id}`}>Balance:</span>
            <span className="font-medium" data-testid={`text-balance-${card.id}`}>
              ${parseFloat(card.balance).toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground" data-testid={`label-status-${card.id}`}>Status:</span>
            <Badge 
              variant={card.status === 'active' ? 'default' : 'secondary'}
              data-testid={`badge-status-${card.id}`}
            >
              {card.status}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground" data-testid={`label-created-${card.id}`}>Created:</span>
            <span className="text-sm text-muted-foreground" data-testid={`text-created-${card.id}`}>
              {new Date(card.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                size="sm" 
                className="flex-1 bg-primary/10 text-primary hover:bg-primary/20"
                data-testid={`button-top-up-${card.id}`}
              >
                <Plus className="w-4 h-4 mr-1" />
                Top Up
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-card" data-testid={`dialog-top-up-${card.id}`}>
              <DialogHeader>
                <DialogTitle data-testid={`text-top-up-title-${card.id}`}>
                  Top Up Card - {card.cardNumber.slice(-4)}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="topup-amount" data-testid={`label-top-up-amount-${card.id}`}>
                    Amount to Add
                  </Label>
                  <Input
                    id="topup-amount"
                    type="number"
                    step="0.01"
                    min="1"
                    placeholder="Enter amount"
                    value={topUpAmount}
                    onChange={(e) => setTopUpAmount(e.target.value)}
                    data-testid={`input-top-up-amount-${card.id}`}
                  />
                </div>
                <Button 
                  onClick={handleTopUp}
                  disabled={topUpMutation.isPending || !topUpAmount}
                  className="w-full"
                  data-testid={`button-confirm-top-up-${card.id}`}
                >
                  {topUpMutation.isPending ? "Processing..." : "Confirm Top Up"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Button
            size="sm"
            variant="outline"
            onClick={onToggleDetails}
            data-testid={`button-toggle-details-${card.id}`}
          >
            {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </Button>

          <Button
            size="sm"
            variant="outline"
            onClick={handleToggleStatus}
            disabled={toggleStatusMutation.isPending}
            className={card.status === 'active' ? 'text-yellow-500 border-yellow-500 hover:bg-yellow-500/10' : 'text-green-500 border-green-500 hover:bg-green-500/10'}
            data-testid={`button-toggle-status-${card.id}`}
          >
            {card.status === 'active' ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
