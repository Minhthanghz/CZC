import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CreditCard, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const { loginMutation, registerMutation, user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Redirect if already authenticated
  if (user) {
    if (user.role === 'admin') {
      setLocation('/admin');
    } else {
      setLocation('/dashboard');
    }
    return null;
  }

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const data = {
      username: formData.get('username') as string,
      password: formData.get('password') as string,
    };

    try {
      loginSchema.parse(data);
      await loginMutation.mutateAsync(data);
      
      // Wait for user data to be available
      setTimeout(() => {
        const currentUser = loginMutation.data;
        if (currentUser?.role === 'admin') {
          setLocation('/admin');
        } else {
          setLocation('/dashboard');
        }
      }, 100);
    } catch (error: any) {
      if (error.errors) {
        toast({
          title: "Validation Error",
          description: error.errors[0].message,
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const data = {
      username: formData.get('username') as string,
      password: formData.get('password') as string,
      confirmPassword: formData.get('confirmPassword') as string,
    };

    try {
      registerSchema.parse(data);
      await registerMutation.mutateAsync({
        username: data.username,
        password: data.password,
      });
      
      // Wait for user data to be available
      setTimeout(() => {
        const currentUser = registerMutation.data;
        if (currentUser?.role === 'admin') {
          setLocation('/admin');
        } else {
          setLocation('/dashboard');
        }
      }, 100);
    } catch (error: any) {
      if (error.errors) {
        toast({
          title: "Validation Error",
          description: error.errors[0].message,
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side - Auth Forms */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md">
          <Card className="glass-card" data-testid="card-auth">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                <CreditCard className="text-primary-foreground text-2xl" />
              </div>
              <CardTitle className="text-3xl font-bold neon-text" data-testid="text-auth-title">
                {isLogin ? "Welcome Back" : "Create Account"}
              </CardTitle>
              <p className="text-muted-foreground mt-2" data-testid="text-auth-subtitle">
                {isLogin ? "Sign in to your CazyCard account" : "Join CazyCard in seconds"}
              </p>
            </CardHeader>

            <CardContent>
              {isLogin ? (
                <form onSubmit={handleLogin} data-testid="form-login">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="username" data-testid="label-username">Username</Label>
                      <Input 
                        id="username"
                        name="username"
                        type="text"
                        required
                        data-testid="input-username"
                        className="bg-input border-border"
                      />
                    </div>
                    <div>
                      <Label htmlFor="password" data-testid="label-password">Password</Label>
                      <Input 
                        id="password"
                        name="password"
                        type="password"
                        required
                        data-testid="input-password"
                        className="bg-input border-border"
                      />
                    </div>
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full mt-6 cyber-glow" 
                    disabled={isLoading}
                    data-testid="button-login"
                  >
                    {isLoading ? "Signing In..." : "Sign In"}
                  </Button>
                </form>
              ) : (
                <form onSubmit={handleRegister} data-testid="form-register">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="reg-username" data-testid="label-reg-username">Username</Label>
                      <Input 
                        id="reg-username"
                        name="username"
                        type="text"
                        required
                        data-testid="input-reg-username"
                        className="bg-input border-border"
                      />
                    </div>
                    <div>
                      <Label htmlFor="reg-password" data-testid="label-reg-password">Password</Label>
                      <Input 
                        id="reg-password"
                        name="password"
                        type="password"
                        required
                        data-testid="input-reg-password"
                        className="bg-input border-border"
                      />
                    </div>
                    <div>
                      <Label htmlFor="confirm-password" data-testid="label-confirm-password">Confirm Password</Label>
                      <Input 
                        id="confirm-password"
                        name="confirmPassword"
                        type="password"
                        required
                        data-testid="input-confirm-password"
                        className="bg-input border-border"
                      />
                    </div>
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full mt-6 cyber-glow" 
                    disabled={isLoading}
                    data-testid="button-register"
                  >
                    {isLoading ? "Creating Account..." : "Create Account"}
                  </Button>
                </form>
              )}

              <div className="text-center mt-6">
                <p className="text-muted-foreground" data-testid="text-switch-auth">
                  {isLogin ? "Don't have an account?" : "Already have an account?"}
                  <Button 
                    variant="link" 
                    onClick={() => setIsLogin(!isLogin)}
                    className="text-primary hover:text-primary/80 ml-2"
                    data-testid="button-switch-auth"
                  >
                    {isLogin ? "Sign up" : "Sign in"}
                  </Button>
                </p>
                <Button 
                  variant="link" 
                  onClick={() => setLocation('/')}
                  className="text-muted-foreground hover:text-foreground mt-2"
                  data-testid="button-back-home"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to home
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Right side - Hero Section */}
      <div className="hidden lg:flex flex-1 items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10 p-12">
        <div className="text-center max-w-lg">
          <div className="w-24 h-24 bg-gradient-to-r from-primary to-accent rounded-2xl flex items-center justify-center mx-auto mb-8">
            <CreditCard className="text-primary-foreground text-4xl" />
          </div>
          <h2 className="text-4xl font-bold mb-6 neon-text" data-testid="text-hero-auth-title">
            Virtual Cards Made Simple
          </h2>
          <p className="text-xl text-muted-foreground mb-8" data-testid="text-hero-auth-description">
            Generate secure virtual cards instantly with USDT-BEP20 funding. No KYC required, bank-level security guaranteed.
          </p>
          <div className="space-y-4 text-left">
            <div className="flex items-center space-x-3" data-testid="feature-instant">
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                <span className="text-primary text-sm">✓</span>
              </div>
              <span className="text-muted-foreground">Instant card generation</span>
            </div>
            <div className="flex items-center space-x-3" data-testid="feature-no-kyc">
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                <span className="text-primary text-sm">✓</span>
              </div>
              <span className="text-muted-foreground">No KYC verification needed</span>
            </div>
            <div className="flex items-center space-x-3" data-testid="feature-crypto">
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                <span className="text-primary text-sm">✓</span>
              </div>
              <span className="text-muted-foreground">USDT-BEP20 deposits</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
