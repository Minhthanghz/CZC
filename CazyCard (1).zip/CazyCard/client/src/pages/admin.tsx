import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Shield,
  Users,
  CreditCard,
  DollarSign,
  Clock,
  TrendingUp,
  Search,
  Plus,
  Minus,
  Check,
  X,
  LogOut,
  Activity,
  CheckCircle,
  XCircle
} from "lucide-react";

export default function AdminPanel() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [balanceAdjustment, setBalanceAdjustment] = useState({ amount: "", action: "add" });
  const { toast } = useToast();

  // Check if user is admin
  if (!user || user.role !== 'admin') {
    setLocation('/dashboard');
    return null;
  }

  // Fetch admin data
  const { data: stats = {} } = useQuery<any>({
    queryKey: ["/api/admin/stats"],
    enabled: !!user && user.role === 'admin',
  });

  const { data: users = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/users", searchQuery],
    enabled: !!user && user.role === 'admin' && activeTab === 'users',
  });

  const { data: pendingDeposits = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/deposits"],
    enabled: !!user && user.role === 'admin' && activeTab === 'deposits',
  });

  const { data: allCards = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/cards"],
    enabled: !!user && user.role === 'admin' && activeTab === 'cards',
  });

  const { data: allTransactions = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/transactions"],
    enabled: !!user && user.role === 'admin' && activeTab === 'logs',
  });

  // Mutations
  const adjustBalanceMutation = useMutation({
    mutationFn: async ({ userId, amount, action }: { userId: string; amount: string; action: string }) => {
      await apiRequest("POST", `/api/admin/users/${userId}/balance`, { amount, action });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Success",
        description: "Balance adjusted successfully",
      });
      setSelectedUser(null);
      setBalanceAdjustment({ amount: "", action: "add" });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const processDepositMutation = useMutation({
    mutationFn: async ({ depositId, status, txHash }: { depositId: string; status: string; txHash?: string }) => {
      await apiRequest("PATCH", `/api/admin/deposits/${depositId}`, { status, txHash });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/deposits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Success",
        description: "Deposit processed successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    setLocation('/');
  };

  const handleAdjustBalance = () => {
    if (!selectedUser || !balanceAdjustment.amount) return;
    
    adjustBalanceMutation.mutate({
      userId: selectedUser.id,
      amount: balanceAdjustment.amount,
      action: balanceAdjustment.action,
    });
  };

  const sidebarItems = [
    { id: "overview", label: "Overview", icon: TrendingUp },
    { id: "users", label: "User Management", icon: Users },
    { id: "deposits", label: "Deposit Requests", icon: DollarSign },
    { id: "cards", label: "Cards Management", icon: CreditCard },
    { id: "logs", label: "Activity Logs", icon: Activity },
  ];

  return (
    <div className="flex h-screen bg-background">
      {/* Admin Sidebar */}
      <div className="glass-card w-64 p-6 border-r border-border" data-testid="admin-sidebar">
        <div className="flex items-center space-x-2 mb-8" data-testid="admin-logo">
          <div className="w-8 h-8 bg-gradient-to-r from-destructive to-red-600 rounded-lg flex items-center justify-center">
            <Shield className="text-white text-sm" />
          </div>
          <span className="text-xl font-bold">Admin Panel</span>
        </div>
        
        <nav className="space-y-2">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeTab === item.id ? "destructive" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab(item.id)}
                data-testid={`admin-nav-${item.id}`}
              >
                <Icon className="w-5 h-5 mr-3" />
                {item.label}
              </Button>
            );
          })}
        </nav>
        
        <div className="mt-auto pt-8">
          <Button
            variant="ghost"
            className="w-full justify-start text-destructive hover:text-destructive"
            onClick={handleLogout}
            data-testid="admin-button-logout"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Sign Out
          </Button>
        </div>
      </div>

      {/* Admin Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-8">
          {/* Overview Tab */}
          {activeTab === "overview" && (
            <div data-testid="admin-overview">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-admin-overview-title">Admin Overview</h1>
                <p className="text-muted-foreground" data-testid="text-admin-overview-subtitle">
                  System statistics and monitoring.
                </p>
              </div>
              
              {/* Admin Stats */}
              <div className="grid md:grid-cols-4 gap-6 mb-8">
                <Card className="glass-card" data-testid="card-total-users">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Total Users</p>
                        <p className="text-3xl font-bold text-primary" data-testid="text-total-users">
                          {stats?.totalUsers || 0}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Users className="text-primary text-xl" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-card" data-testid="card-total-cards">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Total Cards</p>
                        <p className="text-3xl font-bold text-accent" data-testid="text-total-cards">
                          {stats?.totalCards || 0}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <CreditCard className="text-accent text-xl" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-card" data-testid="card-total-volume">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Total Volume</p>
                        <p className="text-3xl font-bold text-green-500" data-testid="text-total-volume">
                          ${stats?.totalVolume || '0.00'}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                        <TrendingUp className="text-green-500 text-xl" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-card" data-testid="card-pending-deposits">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Pending Deposits</p>
                        <p className="text-3xl font-bold text-yellow-500" data-testid="text-pending-deposits">
                          {stats?.pendingDeposits || 0}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-yellow-500/10 rounded-lg flex items-center justify-center">
                        <Clock className="text-yellow-500 text-xl" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* User Management Tab */}
          {activeTab === "users" && (
            <div data-testid="admin-users">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-users-title">User Management</h1>
                <p className="text-muted-foreground" data-testid="text-users-subtitle">
                  Manage all registered users.
                </p>
              </div>

              <Card className="glass-card" data-testid="card-users-management">
                <CardContent className="p-6">
                  {/* Search and Filters */}
                  <div className="flex justify-between items-center mb-6">
                    <div className="flex space-x-4">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                        <Input
                          placeholder="Search users..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10 bg-input border-border"
                          data-testid="input-search-users"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Users Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3" data-testid="header-username">Username</th>
                          <th className="text-left py-3" data-testid="header-balance">Balance</th>
                          <th className="text-left py-3" data-testid="header-role">Role</th>
                          <th className="text-left py-3" data-testid="header-joined">Joined</th>
                          <th className="text-left py-3" data-testid="header-actions">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {users.map((userItem: any) => (
                          <tr key={userItem.id} className="border-b border-border" data-testid={`user-row-${userItem.id}`}>
                            <td className="py-3 font-medium" data-testid={`text-username-${userItem.id}`}>
                              {userItem.username}
                            </td>
                            <td className="py-3" data-testid={`text-balance-${userItem.id}`}>
                              ${parseFloat(userItem.balance).toFixed(2)}
                            </td>
                            <td className="py-3" data-testid={`text-role-${userItem.id}`}>
                              <Badge variant={userItem.role === 'admin' ? 'destructive' : 'default'}>
                                {userItem.role}
                              </Badge>
                            </td>
                            <td className="py-3 text-muted-foreground" data-testid={`text-joined-${userItem.id}`}>
                              {new Date(userItem.createdAt).toLocaleDateString()}
                            </td>
                            <td className="py-3" data-testid={`actions-${userItem.id}`}>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button 
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setSelectedUser(userItem)}
                                    data-testid={`button-adjust-balance-${userItem.id}`}
                                  >
                                    Adjust Balance
                                  </Button>
                                </DialogTrigger>
                                <DialogContent data-testid="dialog-adjust-balance">
                                  <DialogHeader>
                                    <DialogTitle data-testid="text-adjust-balance-title">
                                      Adjust Balance - {selectedUser?.username}
                                    </DialogTitle>
                                  </DialogHeader>
                                  <div className="space-y-4">
                                    <div>
                                      <Label htmlFor="amount" data-testid="label-amount">Amount</Label>
                                      <Input
                                        id="amount"
                                        type="number"
                                        step="0.01"
                                        value={balanceAdjustment.amount}
                                        onChange={(e) => setBalanceAdjustment(prev => ({ ...prev, amount: e.target.value }))}
                                        data-testid="input-adjustment-amount"
                                      />
                                    </div>
                                    <div>
                                      <Label htmlFor="action" data-testid="label-action">Action</Label>
                                      <Select value={balanceAdjustment.action} onValueChange={(value) => setBalanceAdjustment(prev => ({ ...prev, action: value }))}>
                                        <SelectTrigger data-testid="select-adjustment-action">
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="add">Add</SelectItem>
                                          <SelectItem value="subtract">Subtract</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    <div className="flex space-x-2">
                                      <Button 
                                        onClick={handleAdjustBalance}
                                        disabled={adjustBalanceMutation.isPending || !balanceAdjustment.amount}
                                        data-testid="button-confirm-adjustment"
                                      >
                                        {adjustBalanceMutation.isPending ? "Processing..." : "Confirm"}
                                      </Button>
                                    </div>
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Deposit Requests Tab */}
          {activeTab === "deposits" && (
            <div data-testid="admin-deposits">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-deposits-title">Deposit Requests</h1>
                <p className="text-muted-foreground" data-testid="text-deposits-subtitle">
                  Review and approve deposit requests.
                </p>
              </div>

              <Card className="glass-card" data-testid="card-deposits">
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3" data-testid="header-deposit-user">User</th>
                          <th className="text-left py-3" data-testid="header-deposit-amount">Amount</th>
                          <th className="text-left py-3" data-testid="header-deposit-date">Date</th>
                          <th className="text-left py-3" data-testid="header-deposit-status">Status</th>
                          <th className="text-left py-3" data-testid="header-deposit-actions">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pendingDeposits.map((deposit: any) => (
                          <tr key={deposit.id} className="border-b border-border" data-testid={`deposit-row-${deposit.id}`}>
                            <td className="py-3 font-medium" data-testid={`text-deposit-user-${deposit.id}`}>
                              {deposit.userId}
                            </td>
                            <td className="py-3" data-testid={`text-deposit-amount-${deposit.id}`}>
                              ${deposit.exactAmount}
                            </td>
                            <td className="py-3 text-muted-foreground" data-testid={`text-deposit-date-${deposit.id}`}>
                              {new Date(deposit.createdAt).toLocaleDateString()} {new Date(deposit.createdAt).toLocaleTimeString()}
                            </td>
                            <td className="py-3" data-testid={`status-deposit-${deposit.id}`}>
                              <Badge variant="secondary">
                                {deposit.status}
                              </Badge>
                            </td>
                            <td className="py-3" data-testid={`actions-deposit-${deposit.id}`}>
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-green-500 border-green-500 hover:bg-green-500/10"
                                  onClick={() => processDepositMutation.mutate({ 
                                    depositId: deposit.id, 
                                    status: 'approved',
                                    txHash: 'admin_approved' 
                                  })}
                                  disabled={processDepositMutation.isPending}
                                  data-testid={`button-approve-${deposit.id}`}
                                >
                                  <CheckCircle className="w-4 h-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-500 border-red-500 hover:bg-red-500/10"
                                  onClick={() => processDepositMutation.mutate({ 
                                    depositId: deposit.id, 
                                    status: 'rejected' 
                                  })}
                                  disabled={processDepositMutation.isPending}
                                  data-testid={`button-reject-${deposit.id}`}
                                >
                                  <XCircle className="w-4 h-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {pendingDeposits.length === 0 && (
                      <p className="text-muted-foreground text-center py-8" data-testid="text-no-pending-deposits">
                        No pending deposits.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Cards Management Tab */}
          {activeTab === "cards" && (
            <div data-testid="admin-cards">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-cards-management-title">Cards Management</h1>
                <p className="text-muted-foreground" data-testid="text-cards-management-subtitle">
                  Monitor all virtual cards in the system.
                </p>
              </div>

              <Card className="glass-card" data-testid="card-cards-management">
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3" data-testid="header-card-user">User</th>
                          <th className="text-left py-3" data-testid="header-card-number">Card Number</th>
                          <th className="text-left py-3" data-testid="header-card-type">Type</th>
                          <th className="text-left py-3" data-testid="header-card-balance">Balance</th>
                          <th className="text-left py-3" data-testid="header-card-status">Status</th>
                          <th className="text-left py-3" data-testid="header-card-created">Created</th>
                        </tr>
                      </thead>
                      <tbody>
                        {allCards.map((card: any) => (
                          <tr key={card.id} className="border-b border-border" data-testid={`card-row-${card.id}`}>
                            <td className="py-3 font-medium" data-testid={`text-card-user-${card.id}`}>
                              {card.userId}
                            </td>
                            <td className="py-3 font-mono" data-testid={`text-card-number-${card.id}`}>
                              **** **** **** {card.cardNumber.slice(-4)}
                            </td>
                            <td className="py-3" data-testid={`text-card-type-${card.id}`}>
                              <Badge variant="outline">
                                {card.cardType.toUpperCase()}
                              </Badge>
                            </td>
                            <td className="py-3" data-testid={`text-card-balance-${card.id}`}>
                              ${parseFloat(card.balance).toFixed(2)}
                            </td>
                            <td className="py-3" data-testid={`status-card-${card.id}`}>
                              <Badge variant={card.status === 'active' ? 'default' : 'secondary'}>
                                {card.status}
                              </Badge>
                            </td>
                            <td className="py-3 text-muted-foreground" data-testid={`text-card-created-${card.id}`}>
                              {new Date(card.createdAt).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {allCards.length === 0 && (
                      <p className="text-muted-foreground text-center py-8" data-testid="text-no-cards">
                        No cards generated yet.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Activity Logs Tab */}
          {activeTab === "logs" && (
            <div data-testid="admin-logs">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-logs-title">Activity Logs</h1>
                <p className="text-muted-foreground" data-testid="text-logs-subtitle">
                  Monitor all system transactions and activities.
                </p>
              </div>

              <Card className="glass-card" data-testid="card-activity-logs">
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3" data-testid="header-log-user">User</th>
                          <th className="text-left py-3" data-testid="header-log-type">Type</th>
                          <th className="text-left py-3" data-testid="header-log-amount">Amount</th>
                          <th className="text-left py-3" data-testid="header-log-status">Status</th>
                          <th className="text-left py-3" data-testid="header-log-date">Date</th>
                          <th className="text-left py-3" data-testid="header-log-description">Description</th>
                        </tr>
                      </thead>
                      <tbody>
                        {allTransactions.map((transaction: any) => (
                          <tr key={transaction.id} className="border-b border-border" data-testid={`log-row-${transaction.id}`}>
                            <td className="py-3 font-medium" data-testid={`text-log-user-${transaction.id}`}>
                              {transaction.userId}
                            </td>
                            <td className="py-3" data-testid={`text-log-type-${transaction.id}`}>
                              <Badge variant="outline" className="capitalize">
                                {transaction.type.replace('_', ' ')}
                              </Badge>
                            </td>
                            <td className={`py-3 font-medium ${parseFloat(transaction.amount) >= 0 ? 'text-green-500' : 'text-red-500'}`} data-testid={`text-log-amount-${transaction.id}`}>
                              {parseFloat(transaction.amount) >= 0 ? '+' : ''}${Math.abs(parseFloat(transaction.amount)).toFixed(2)}
                            </td>
                            <td className="py-3" data-testid={`status-log-${transaction.id}`}>
                              <Badge variant={transaction.status === 'completed' ? 'default' : 'secondary'}>
                                {transaction.status}
                              </Badge>
                            </td>
                            <td className="py-3 text-muted-foreground" data-testid={`text-log-date-${transaction.id}`}>
                              {new Date(transaction.createdAt).toLocaleDateString()} {new Date(transaction.createdAt).toLocaleTimeString()}
                            </td>
                            <td className="py-3 text-muted-foreground" data-testid={`text-log-description-${transaction.id}`}>
                              {transaction.description}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {allTransactions.length === 0 && (
                      <p className="text-muted-foreground text-center py-8" data-testid="text-no-logs">
                        No activity logs found.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
