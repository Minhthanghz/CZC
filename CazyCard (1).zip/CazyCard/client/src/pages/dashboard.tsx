import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  CreditCard,
  Wallet,
  PlusCircle,
  History,
  Settings,
  LogOut,
  TrendingUp,
  Plus,
  Eye,
  EyeOff
} from "lucide-react";
import { DepositModal } from "../components/deposit-modal";
import { CardGenerationForm } from "../components/card-generation-form";
import { VirtualCard } from "../components/virtual-card";

export default function Dashboard() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [showCardDetails, setShowCardDetails] = useState<Record<string, boolean>>({});

  // Fetch user data
  const { data: cards = [] } = useQuery<any[]>({
    queryKey: ["/api/cards"],
    enabled: !!user,
  });

  const { data: transactions = [] } = useQuery<any[]>({
    queryKey: ["/api/transactions"],
    enabled: !!user,
  });

  const { data: deposits = [] } = useQuery<any[]>({
    queryKey: ["/api/deposits"],
    enabled: !!user,
  });

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    setLocation('/');
  };

  const toggleCardDetails = (cardId: string) => {
    setShowCardDetails(prev => ({
      ...prev,
      [cardId]: !prev[cardId]
    }));
  };

  if (!user) {
    setLocation('/auth');
    return null;
  }

  const balance = parseFloat(user.balance || '0');
  const activeCards = cards.filter((card: any) => card.status === 'active').length;
  const thisMonthSpent = transactions
    .filter((t: any) => {
      const transactionDate = new Date(t.createdAt);
      const now = new Date();
      return transactionDate.getMonth() === now.getMonth() && 
             transactionDate.getFullYear() === now.getFullYear() &&
             parseFloat(t.amount) < 0;
    })
    .reduce((sum: number, t: any) => sum + Math.abs(parseFloat(t.amount)), 0);

  const sidebarItems = [
    { id: "overview", label: "Dashboard", icon: TrendingUp },
    { id: "wallet", label: "Wallet", icon: Wallet },
    { id: "generate", label: "Generate Card", icon: PlusCircle },
    { id: "cards", label: "My Cards", icon: CreditCard },
    { id: "transactions", label: "Transactions", icon: History },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="glass-card w-64 p-6 border-r border-border" data-testid="sidebar">
        <div className="flex items-center space-x-2 mb-8" data-testid="logo-dashboard">
          <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
            <CreditCard className="text-primary-foreground text-sm" />
          </div>
          <span className="text-xl font-bold">CazyCard</span>
        </div>
        
        <nav className="space-y-2">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeTab === item.id ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab(item.id)}
                data-testid={`nav-${item.id}`}
              >
                <Icon className="w-5 h-5 mr-3" />
                {item.label}
              </Button>
            );
          })}
        </nav>
        
        <div className="mt-auto pt-8">
          <Button
            variant="ghost"
            className="w-full justify-start text-destructive hover:text-destructive"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Sign Out
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-8">
          {/* Overview Tab */}
          {activeTab === "overview" && (
            <div data-testid="dashboard-overview">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-dashboard-title">Dashboard</h1>
                <p className="text-muted-foreground" data-testid="text-dashboard-subtitle">
                  Welcome back, {user.username}! Here's your account overview.
                </p>
              </div>

              {/* Stats Cards */}
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <Card className="glass-card" data-testid="card-wallet-balance">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Wallet Balance</p>
                        <p className="text-3xl font-bold text-primary" data-testid="text-wallet-balance">
                          ${balance.toFixed(2)}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Wallet className="text-primary text-xl" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-card" data-testid="card-active-cards">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Active Cards</p>
                        <p className="text-3xl font-bold text-accent" data-testid="text-active-cards">
                          {activeCards}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <CreditCard className="text-accent text-xl" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="glass-card" data-testid="card-month-spent">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">This Month</p>
                        <p className="text-3xl font-bold text-green-500" data-testid="text-month-spent">
                          ${thisMonthSpent.toFixed(2)}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                        <TrendingUp className="text-green-500 text-xl" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <Card className="glass-card" data-testid="card-recent-activity">
                <CardHeader>
                  <CardTitle data-testid="text-recent-activity-title">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {transactions.slice(0, 5).map((transaction: any) => (
                      <div key={transaction.id} className="flex items-center justify-between py-3 border-b border-border last:border-0" data-testid={`transaction-${transaction.id}`}>
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            transaction.type === 'deposit' ? 'bg-green-500/10' :
                            transaction.type === 'card_generation' ? 'bg-primary/10' :
                            'bg-accent/10'
                          }`}>
                            {transaction.type === 'deposit' && <Plus className="text-green-500 text-sm" />}
                            {transaction.type === 'card_generation' && <CreditCard className="text-primary text-sm" />}
                            {transaction.type === 'top_up' && <Plus className="text-accent text-sm" />}
                          </div>
                          <div>
                            <p className="font-medium" data-testid={`text-transaction-description-${transaction.id}`}>
                              {transaction.description}
                            </p>
                            <p className="text-sm text-muted-foreground" data-testid={`text-transaction-date-${transaction.id}`}>
                              {new Date(transaction.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <Badge variant={transaction.status === 'completed' ? 'default' : 'secondary'} data-testid={`badge-transaction-status-${transaction.id}`}>
                          {transaction.status}
                        </Badge>
                      </div>
                    ))}
                    {transactions.length === 0 && (
                      <p className="text-muted-foreground text-center py-8" data-testid="text-no-transactions">
                        No transactions yet. Start by making a deposit!
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Wallet Tab */}
          {activeTab === "wallet" && (
            <div data-testid="dashboard-wallet">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-wallet-title">Wallet</h1>
                <p className="text-muted-foreground" data-testid="text-wallet-subtitle">
                  Manage your deposits and balance.
                </p>
              </div>

              {/* Balance Card */}
              <Card className="glass-card mb-8" data-testid="card-balance">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground">Available Balance</p>
                      <p className="text-4xl font-bold text-primary" data-testid="text-available-balance">
                        ${balance.toFixed(2)}
                      </p>
                    </div>
                    <Button 
                      onClick={() => setShowDepositModal(true)}
                      className="cyber-glow"
                      data-testid="button-make-deposit"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Make Deposit
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Deposit History */}
              <Card className="glass-card" data-testid="card-deposit-history">
                <CardHeader>
                  <CardTitle data-testid="text-deposit-history-title">Deposit History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3" data-testid="header-amount">Amount</th>
                          <th className="text-left py-3" data-testid="header-status">Status</th>
                          <th className="text-left py-3" data-testid="header-date">Date</th>
                          <th className="text-left py-3" data-testid="header-tx-hash">TX Hash</th>
                        </tr>
                      </thead>
                      <tbody>
                        {deposits.map((deposit: any) => (
                          <tr key={deposit.id} className="border-b border-border" data-testid={`deposit-row-${deposit.id}`}>
                            <td className="py-3 font-medium" data-testid={`text-deposit-amount-${deposit.id}`}>
                              ${deposit.exactAmount}
                            </td>
                            <td className="py-3" data-testid={`status-deposit-${deposit.id}`}>
                              <Badge variant={
                                deposit.status === 'approved' ? 'default' :
                                deposit.status === 'rejected' ? 'destructive' :
                                'secondary'
                              }>
                                {deposit.status}
                              </Badge>
                            </td>
                            <td className="py-3 text-muted-foreground" data-testid={`text-deposit-date-${deposit.id}`}>
                              {new Date(deposit.createdAt).toLocaleDateString()}
                            </td>
                            <td className="py-3 text-muted-foreground font-mono text-sm" data-testid={`text-deposit-hash-${deposit.id}`}>
                              {deposit.txHash ? `${deposit.txHash.slice(0, 8)}...${deposit.txHash.slice(-4)}` : '-'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {deposits.length === 0 && (
                      <p className="text-muted-foreground text-center py-8" data-testid="text-no-deposits">
                        No deposits yet. Make your first deposit to get started!
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Generate Card Tab */}
          {activeTab === "generate" && (
            <div data-testid="dashboard-generate">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-generate-title">Generate Card</h1>
                <p className="text-muted-foreground" data-testid="text-generate-subtitle">
                  Create a new virtual card instantly.
                </p>
              </div>
              <CardGenerationForm />
            </div>
          )}

          {/* My Cards Tab */}
          {activeTab === "cards" && (
            <div data-testid="dashboard-cards">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-cards-title">My Cards</h1>
                <p className="text-muted-foreground" data-testid="text-cards-subtitle">
                  Manage your virtual cards.
                </p>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {cards.map((card: any) => (
                  <VirtualCard 
                    key={card.id} 
                    card={card} 
                    showDetails={showCardDetails[card.id] || false}
                    onToggleDetails={() => toggleCardDetails(card.id)}
                  />
                ))}
                {cards.length === 0 && (
                  <div className="col-span-full text-center py-12" data-testid="no-cards-message">
                    <CreditCard className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground text-lg mb-4">No cards generated yet</p>
                    <Button 
                      onClick={() => setActiveTab("generate")}
                      className="cyber-glow"
                      data-testid="button-generate-first-card"
                    >
                      Generate Your First Card
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Transactions Tab */}
          {activeTab === "transactions" && (
            <div data-testid="dashboard-transactions">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-transactions-title">Transactions</h1>
                <p className="text-muted-foreground" data-testid="text-transactions-subtitle">
                  View all your transaction history.
                </p>
              </div>

              <Card className="glass-card" data-testid="card-transactions">
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3" data-testid="header-transaction-type">Type</th>
                          <th className="text-left py-3" data-testid="header-transaction-amount">Amount</th>
                          <th className="text-left py-3" data-testid="header-transaction-status">Status</th>
                          <th className="text-left py-3" data-testid="header-transaction-date">Date</th>
                          <th className="text-left py-3" data-testid="header-transaction-details">Details</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.map((transaction: any) => (
                          <tr key={transaction.id} className="border-b border-border" data-testid={`transaction-row-${transaction.id}`}>
                            <td className="py-3" data-testid={`text-transaction-type-${transaction.id}`}>
                              <div className="flex items-center space-x-2">
                                {transaction.type === 'deposit' && <Plus className="text-green-500 w-4 h-4" />}
                                {transaction.type === 'card_generation' && <CreditCard className="text-primary w-4 h-4" />}
                                {transaction.type === 'top_up' && <Plus className="text-accent w-4 h-4" />}
                                <span className="capitalize">{transaction.type.replace('_', ' ')}</span>
                              </div>
                            </td>
                            <td className={`py-3 font-medium ${parseFloat(transaction.amount) >= 0 ? 'text-green-500' : 'text-red-500'}`} data-testid={`text-transaction-amount-${transaction.id}`}>
                              {parseFloat(transaction.amount) >= 0 ? '+' : ''}${Math.abs(parseFloat(transaction.amount)).toFixed(2)}
                            </td>
                            <td className="py-3" data-testid={`status-transaction-${transaction.id}`}>
                              <Badge variant={transaction.status === 'completed' ? 'default' : 'secondary'}>
                                {transaction.status}
                              </Badge>
                            </td>
                            <td className="py-3 text-muted-foreground" data-testid={`text-transaction-date-${transaction.id}`}>
                              {new Date(transaction.createdAt).toLocaleDateString()} {new Date(transaction.createdAt).toLocaleTimeString()}
                            </td>
                            <td className="py-3 text-muted-foreground" data-testid={`text-transaction-details-${transaction.id}`}>
                              {transaction.description}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {transactions.length === 0 && (
                      <p className="text-muted-foreground text-center py-8" data-testid="text-no-transactions">
                        No transactions found.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === "settings" && (
            <div data-testid="dashboard-settings">
              <div className="mb-8">
                <h1 className="text-3xl font-bold neon-text" data-testid="text-settings-title">Settings</h1>
                <p className="text-muted-foreground" data-testid="text-settings-subtitle">
                  Manage your account preferences.
                </p>
              </div>

              <div className="max-w-2xl space-y-6">
                {/* Change Password */}
                <Card className="glass-card" data-testid="card-change-password">
                  <CardHeader>
                    <CardTitle data-testid="text-change-password-title">Change Password</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-4" data-testid="form-change-password">
                      <div>
                        <label className="block text-sm font-medium mb-2" data-testid="label-current-password">Current Password</label>
                        <input type="password" className="w-full bg-input border border-border rounded-lg px-4 py-3 focus:ring-2 focus:ring-ring focus:border-transparent" data-testid="input-current-password" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2" data-testid="label-new-password">New Password</label>
                        <input type="password" className="w-full bg-input border border-border rounded-lg px-4 py-3 focus:ring-2 focus:ring-ring focus:border-transparent" data-testid="input-new-password" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2" data-testid="label-confirm-new-password">Confirm New Password</label>
                        <input type="password" className="w-full bg-input border border-border rounded-lg px-4 py-3 focus:ring-2 focus:ring-ring focus:border-transparent" data-testid="input-confirm-new-password" />
                      </div>
                      <Button type="button" data-testid="button-update-password">
                        Update Password
                      </Button>
                    </form>
                  </CardContent>
                </Card>

                {/* Preferences */}
                <Card className="glass-card" data-testid="card-preferences">
                  <CardHeader>
                    <CardTitle data-testid="text-preferences-title">Preferences</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between" data-testid="setting-language">
                        <div>
                          <p className="font-medium" data-testid="text-language-label">Language</p>
                          <p className="text-sm text-muted-foreground" data-testid="text-language-description">Choose your preferred language</p>
                        </div>
                        <select className="bg-input border border-border rounded-lg px-4 py-2 focus:ring-2 focus:ring-ring focus:border-transparent" data-testid="select-language">
                          <option value="en">English</option>
                          <option value="vi">Vietnamese</option>
                        </select>
                      </div>
                      <div className="flex items-center justify-between" data-testid="setting-theme">
                        <div>
                          <p className="font-medium" data-testid="text-theme-label">Theme</p>
                          <p className="text-sm text-muted-foreground" data-testid="text-theme-description">Switch between dark and light mode</p>
                        </div>
                        <select className="bg-input border border-border rounded-lg px-4 py-2 focus:ring-2 focus:ring-ring focus:border-transparent" data-testid="select-theme">
                          <option value="dark">Dark (Cyberpunk)</option>
                          <option value="light">Light</option>
                        </select>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <DepositModal 
        open={showDepositModal} 
        onOpenChange={setShowDepositModal}
      />
    </div>
  );
}
