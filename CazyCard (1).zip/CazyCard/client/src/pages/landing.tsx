import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CreditCard, Shield, Zap, Bitcoin, Users, ChartLine, Clock } from "lucide-react";
import { useEffect } from "react";

export default function LandingPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user) {
      if (user.role === 'admin') {
        setLocation('/admin');
      } else {
        setLocation('/dashboard');
      }
    }
  }, [user, setLocation]);

  const handleGetStarted = () => {
    setLocation('/auth');
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="glass-card fixed top-0 left-0 right-0 z-50 px-6 py-4" data-testid="navbar">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2" data-testid="logo">
            <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
              <CreditCard className="text-primary-foreground text-sm" />
            </div>
            <span className="text-xl font-bold neon-text">CazyCard</span>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-features">Features</a>
            <a href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-pricing">Pricing</a>
            <a href="#faq" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-faq">FAQ</a>
            <a href="#contact" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-contact">Contact</a>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => setLocation('/auth')} data-testid="button-login">
              Login
            </Button>
            <Button onClick={handleGetStarted} className="cyber-glow" data-testid="button-get-started">
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6" data-testid="hero-section">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 neon-text" data-testid="text-hero-title">
            Generate Virtual Cards in{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Seconds
            </span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-hero-description">
            Create secure virtual cards instantly for online payments. No KYC required, powered by advanced encryption.
          </p>
          <Button 
            onClick={handleGetStarted} 
            size="lg"
            className="bg-gradient-to-r from-primary to-accent text-primary-foreground px-8 py-4 text-lg font-semibold hover:scale-105 transition-transform cyber-glow"
            data-testid="button-create-first-card"
          >
            Create Your First Card
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-6" data-testid="features-section">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 neon-text" data-testid="text-features-title">
            Why Choose CazyCard?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="glass-card p-8" data-testid="card-feature-instant">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center mb-6">
                  <Zap className="text-primary-foreground text-2xl" />
                </div>
                <h3 className="text-2xl font-semibold mb-4" data-testid="text-feature-instant-title">Instant Generation</h3>
                <p className="text-muted-foreground" data-testid="text-feature-instant-description">
                  Create virtual cards in seconds with our advanced API integration. No waiting, no delays.
                </p>
              </CardContent>
            </Card>
            <Card className="glass-card p-8" data-testid="card-feature-security">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center mb-6">
                  <Shield className="text-primary-foreground text-2xl" />
                </div>
                <h3 className="text-2xl font-semibold mb-4" data-testid="text-feature-security-title">Bank-Level Security</h3>
                <p className="text-muted-foreground" data-testid="text-feature-security-description">
                  Advanced encryption and security measures protect your transactions and personal data.
                </p>
              </CardContent>
            </Card>
            <Card className="glass-card p-8" data-testid="card-feature-crypto">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center mb-6">
                  <Bitcoin className="text-primary-foreground text-2xl" />
                </div>
                <h3 className="text-2xl font-semibold mb-4" data-testid="text-feature-crypto-title">USDT-BEP20 Funding</h3>
                <p className="text-muted-foreground" data-testid="text-feature-crypto-description">
                  Fund your account easily with USDT-BEP20. Fast, secure, and anonymous transactions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-6" data-testid="pricing-section">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-16 neon-text" data-testid="text-pricing-title">
            Transparent Pricing
          </h2>
          <Card className="glass-card p-8" data-testid="card-pricing">
            <CardContent className="p-0">
              <div className="grid md:grid-cols-2 gap-8">
                <div data-testid="pricing-card-generation">
                  <h3 className="text-2xl font-semibold mb-4 text-primary" data-testid="text-pricing-card-title">
                    Card Generation
                  </h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li data-testid="text-pricing-card-creation">• Card Creation: $2.00</li>
                    <li data-testid="text-pricing-card-maintenance">• Monthly Maintenance: $1.00</li>
                    <li data-testid="text-pricing-card-load-fee">• Load Fee: 3%</li>
                  </ul>
                </div>
                <div data-testid="pricing-deposit-options">
                  <h3 className="text-2xl font-semibold mb-4 text-accent" data-testid="text-pricing-deposit-title">
                    Deposit Options
                  </h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li data-testid="text-pricing-deposit-small">• $50 - $100: Instant</li>
                    <li data-testid="text-pricing-deposit-medium">• $200 - $1,000: 1-2 hours</li>
                    <li data-testid="text-pricing-deposit-large">• $2,000 - $5,000: Manual review</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 px-6" data-testid="faq-section">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 neon-text" data-testid="text-faq-title">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <Card className="glass-card p-6" data-testid="card-faq-kyc">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold mb-3 text-primary" data-testid="text-faq-kyc-question">
                  Do I need to provide KYC documents?
                </h3>
                <p className="text-muted-foreground" data-testid="text-faq-kyc-answer">
                  No, CazyCard operates without requiring KYC verification. Simply create an account with username and password.
                </p>
              </CardContent>
            </Card>
            <Card className="glass-card p-6" data-testid="card-faq-speed">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold mb-3 text-primary" data-testid="text-faq-speed-question">
                  How fast are card generation?
                </h3>
                <p className="text-muted-foreground" data-testid="text-faq-speed-answer">
                  Virtual cards are generated instantly through our API integration once you have sufficient balance in your wallet.
                </p>
              </CardContent>
            </Card>
            <Card className="glass-card p-6" data-testid="card-faq-crypto">
              <CardContent className="p-0">
                <h3 className="text-xl font-semibold mb-3 text-primary" data-testid="text-faq-crypto-question">
                  What cryptocurrencies do you accept?
                </h3>
                <p className="text-muted-foreground" data-testid="text-faq-crypto-answer">
                  Currently we accept USDT-BEP20 deposits to our fixed wallet address for maximum security and tracking.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-6 border-t border-border" data-testid="footer">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div data-testid="footer-brand">
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
                  <CreditCard className="text-primary-foreground text-sm" />
                </div>
                <span className="text-xl font-bold" data-testid="text-footer-brand">CazyCard</span>
              </div>
              <p className="text-muted-foreground" data-testid="text-footer-tagline">
                Virtual cards made simple, secure, and instant.
              </p>
            </div>
            <div data-testid="footer-product">
              <h4 className="font-semibold mb-4" data-testid="text-footer-product-title">Product</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#features" className="hover:text-foreground transition-colors" data-testid="link-footer-features">Features</a></li>
                <li><a href="#pricing" className="hover:text-foreground transition-colors" data-testid="link-footer-pricing">Pricing</a></li>
                <li><a href="#faq" className="hover:text-foreground transition-colors" data-testid="link-footer-faq">FAQ</a></li>
              </ul>
            </div>
            <div data-testid="footer-support">
              <h4 className="font-semibold mb-4" data-testid="text-footer-support-title">Support</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors" data-testid="link-footer-help">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors" data-testid="link-footer-contact">Contact Us</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors" data-testid="link-footer-api">API Docs</a></li>
              </ul>
            </div>
            <div data-testid="footer-community">
              <h4 className="font-semibold mb-4" data-testid="text-footer-community-title">Community</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors" data-testid="link-footer-telegram">Telegram</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors" data-testid="link-footer-discord">Discord</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors" data-testid="link-footer-twitter">Twitter</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-12 pt-8 text-center text-muted-foreground" data-testid="footer-copyright">
            <p>&copy; 2024 CazyCard. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
