import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { storage } from "./storage";
import { GPayCardService } from "./services/gpaycard";
import { BlockchainService } from "./services/blockchain";
import { authenticateToken, requireAdmin } from "./middleware/auth";
import { insertUserSchema, loginSchema, insertDepositSchema, insertCardSchema, cardTopupSchema } from "@shared/schema";

const JWT_SECRET = process.env.SESSION_SECRET || 'your-secret-key';
const gpayCardService = new GPayCardService();
const blockchainService = new BlockchainService();

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Auth Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists with this email" });
      }

      const existingUsername = await storage.getUserByUsername(validatedData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }

      // Hash password and create user
      const hashedPassword = await bcrypt.hash(validatedData.password, 12);
      const referralCode = `${validatedData.username}_${Date.now()}`;
      
      const user = await storage.createUser({
        email: validatedData.email,
        username: validatedData.username,
        password: hashedPassword,
        referralCode,
        referredBy: req.body.referredBy || null,
      });

      // Handle referral
      if (req.body.referredBy) {
        const referrer = await storage.getUserByReferralCode(req.body.referredBy);
        if (referrer) {
          await storage.createReferral(referrer.id, user.id);
        }
      }

      res.json({ message: "Registration successful", userId: user.id });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { emailOrUsername, password } = loginSchema.parse(req.body);
      
      let user = await storage.getUserByEmail(emailOrUsername);
      if (!user) {
        user = await storage.getUserByUsername(emailOrUsername);
      }
      
      if (!user || !await bcrypt.compare(password, user.password)) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ userId: user.id, isAdmin: user.isAdmin }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({
        token,
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          balance: user.balance,
          isAdmin: user.isAdmin,
          referralCode: user.referralCode,
        }
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        id: user.id,
        email: user.email,
        username: user.username,
        balance: user.balance,
        isAdmin: user.isAdmin,
        referralCode: user.referralCode,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Deposit Routes
  app.post("/api/deposits", authenticateToken, async (req, res) => {
    try {
      const { amount } = insertDepositSchema.parse(req.body);
      
      // Generate random 4 decimal digits
      const randomDecimals = Math.floor(Math.random() * 10000);
      const exactAmount = amount + (randomDecimals / 10000);
      
      const deposit = await storage.createDeposit({
        userId: req.user.userId,
        amount: amount.toString(),
        exactAmount: exactAmount.toString(),
        walletAddress: "0x463f5d4c8a62403a0a28a60712347ae215dab39c",
      });

      res.json({
        depositId: deposit.id,
        amount: amount,
        exactAmount: exactAmount,
        walletAddress: deposit.walletAddress,
        qrCodeData: `${deposit.walletAddress}?amount=${exactAmount}`,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/deposits", authenticateToken, async (req, res) => {
    try {
      const deposits = await storage.getUserDeposits(req.user.userId);
      res.json(deposits);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Card Routes
  app.post("/api/cards", authenticateToken, async (req, res) => {
    try {
      const { cardholderName, cardLimit } = insertCardSchema.parse(req.body);
      
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const cardGenerationFee = 3.00;
      if (parseFloat(user.balance) < cardGenerationFee) {
        return res.status(400).json({ message: "Insufficient balance for card generation" });
      }

      // Generate card using GPayCard API
      const cardData = await gpayCardService.createCard({
        cardholderName,
        cardLimit,
      });

      // Deduct fee and create card record
      await storage.updateUserBalance(req.user.userId, -cardGenerationFee, 'card_generation', 'Card generation fee');
      
      const card = await storage.createCard({
        userId: req.user.userId,
        cardNumber: cardData.cardNumber,
        expiryMonth: cardData.expiryMonth,
        expiryYear: cardData.expiryYear,
        cvv: cardData.cvv,
        cardholderName,
        cardLimit: cardLimit.toString(),
        gpayCardId: cardData.id,
      });

      res.json({
        cardId: card.id,
        cardNumber: card.cardNumber,
        expiryMonth: card.expiryMonth,
        expiryYear: card.expiryYear,
        cvv: card.cvv,
        cardholderName: card.cardholderName,
        balance: card.balance,
        cardLimit: card.cardLimit,
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/cards", authenticateToken, async (req, res) => {
    try {
      const cards = await storage.getUserCards(req.user.userId);
      res.json(cards);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/cards/:cardId/topup", authenticateToken, async (req, res) => {
    try {
      const { amount } = cardTopupSchema.parse({ ...req.body, cardId: req.params.cardId });
      
      const user = await storage.getUser(req.user.userId);
      const card = await storage.getCard(req.params.cardId);
      
      if (!user || !card) {
        return res.status(404).json({ message: "User or card not found" });
      }

      if (card.userId !== req.user.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      if (parseFloat(user.balance) < amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Transfer funds from user balance to card
      await storage.updateUserBalance(req.user.userId, -amount, 'card_topup', `Top-up card ending in ${card.cardNumber.slice(-4)}`);
      await storage.updateCardBalance(req.params.cardId, amount);

      res.json({ message: "Card topped up successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Transaction Routes
  app.get("/api/transactions", authenticateToken, async (req, res) => {
    try {
      const transactions = await storage.getUserTransactions(req.user.userId);
      res.json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/transactions/card/:cardId", authenticateToken, async (req, res) => {
    try {
      const transactions = await storage.getCardTransactions(req.params.cardId, req.user.userId);
      res.json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Referral Routes
  app.get("/api/referrals", authenticateToken, async (req, res) => {
    try {
      const referralStats = await storage.getReferralStats(req.user.userId);
      const recentReferrals = await storage.getRecentReferrals(req.user.userId);
      
      res.json({
        stats: referralStats,
        recentReferrals: recentReferrals,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Dashboard Stats
  app.get("/api/dashboard/stats", authenticateToken, async (req, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      const cards = await storage.getUserCards(req.user.userId);
      const referralStats = await storage.getReferralStats(req.user.userId);
      const recentTransactions = await storage.getUserTransactions(req.user.userId, 5);

      res.json({
        balance: user?.balance || '0.00',
        activeCards: cards.filter(card => card.status === 'active').length,
        referralEarnings: referralStats?.totalEarnings || '0.00',
        recentTransactions: recentTransactions,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Admin Routes
  app.get("/api/admin/stats", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/users", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/deposits", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const status = req.query.status as string;
      const deposits = await storage.getAllDeposits(status);
      res.json(deposits);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/deposits/:depositId/approve", authenticateToken, requireAdmin, async (req, res) => {
    try {
      await storage.approveDeposit(req.params.depositId);
      res.json({ message: "Deposit approved successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/admin/deposits/:depositId/reject", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { reason } = req.body;
      await storage.rejectDeposit(req.params.depositId, reason);
      res.json({ message: "Deposit rejected successfully" });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/admin/cards", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const cards = await storage.getAllCards();
      res.json(cards);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
