import { 
  users, deposits, cards, transactions, referrals,
  type User, type InsertUser, type Deposit, type Card, type Transaction, type Referral,
  type UserWithStats 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";
import { nanoid } from "nanoid";

// Storage interface definition
export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByReferralCode(referralCode: string): Promise<User | undefined>;
  createUser(insertUser: Omit<InsertUser, 'confirmPassword'> & { referralCode: string }): Promise<User>;
  getAllUsers(): Promise<UserWithStats[]>;
  updateUserBalance(userId: string, amount: number, transactionType: string, description: string): Promise<void>;

  // Deposit methods
  createDeposit(deposit: { userId: string; amount: string; exactAmount: string; walletAddress: string }): Promise<Deposit>;
  getUserDeposits(userId: string): Promise<Deposit[]>;
  getAllDeposits(status?: string): Promise<Deposit[]>;
  approveDeposit(depositId: string): Promise<void>;
  rejectDeposit(depositId: string, reason: string): Promise<void>;

  // Card methods
  createCard(card: { userId: string; cardNumber: string; expiryMonth: string; expiryYear: string; cvv: string; cardholderName: string; cardLimit: string; gpayCardId: string }): Promise<Card>;
  getCard(cardId: string): Promise<Card | undefined>;
  getUserCards(userId: string): Promise<Card[]>;
  getAllCards(): Promise<Card[]>;
  updateCardBalance(cardId: string, amount: number): Promise<void>;

  // Transaction methods
  getUserTransactions(userId: string, limit?: number): Promise<Transaction[]>;
  getCardTransactions(cardId: string, userId: string): Promise<Transaction[]>;

  // Referral methods
  createReferral(referrerId: string, referredUserId: string): Promise<void>;
  getReferralStats(userId: string): Promise<{ totalEarnings: string; totalReferrals: number }>;
  getRecentReferrals(userId: string): Promise<Array<{
    id: string;
    username: string;
    createdAt: string;
    commissionEarned: string;
    depositAmount?: string;
  }>>;

  // Admin methods
  getAdminStats(): Promise<{
    totalUsers: number;
    activeCards: number;
    totalVolume: string;
    revenue: string;
    recentActivity: Array<{
      id: string;
      type: string;
      description: string;
      details: string;
      timestamp: string;
    }>;
  }>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByReferralCode(referralCode: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.referralCode, referralCode));
    return user || undefined;
  }

  async createUser(insertUser: Omit<InsertUser, 'confirmPassword'> & { referralCode: string }): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllUsers(): Promise<UserWithStats[]> {
    const allUsers = await db.select().from(users);
    
    // Get aggregated stats for each user
    const usersWithStats = await Promise.all(
      allUsers.map(async (user) => {
        const [cardCount] = await db
          .select({ count: sql<number>`COUNT(*)` })
          .from(cards)
          .where(eq(cards.userId, user.id));

        const [referralStats] = await db
          .select({ 
            totalEarnings: sql<string>`COALESCE(SUM(${referrals.totalCommissionEarned}), 0)`,
            referralCount: sql<number>`COUNT(*)`
          })
          .from(referrals)
          .where(eq(referrals.referrerId, user.id));

        return {
          ...user,
          activeCards: cardCount?.count || 0,
          totalEarnings: referralStats?.totalEarnings || '0.00',
          referralCount: referralStats?.referralCount || 0,
        } as UserWithStats;
      })
    );

    return usersWithStats;
  }

  async updateUserBalance(userId: string, amount: number, transactionType: string, description: string): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");

    const currentBalance = parseFloat(user.balance);
    const newBalance = currentBalance + amount;
    
    await db.transaction(async (tx) => {
      await tx
        .update(users)
        .set({ balance: newBalance.toString() })
        .where(eq(users.id, userId));

      await tx.insert(transactions).values({
        userId,
        type: transactionType as any,
        amount: amount.toString(),
        description,
        balanceBefore: currentBalance.toString(),
        balanceAfter: newBalance.toString(),
      });
    });
  }

  async createDeposit(deposit: { userId: string; amount: string; exactAmount: string; walletAddress: string }): Promise<Deposit> {
    const [newDeposit] = await db
      .insert(deposits)
      .values(deposit)
      .returning();
    return newDeposit;
  }

  async getUserDeposits(userId: string): Promise<Deposit[]> {
    return await db.select().from(deposits).where(eq(deposits.userId, userId)).orderBy(desc(deposits.createdAt));
  }

  async getAllDeposits(status?: string): Promise<Deposit[]> {
    if (status && status !== 'all') {
      return await db.select().from(deposits).where(eq(deposits.status, status as any)).orderBy(desc(deposits.createdAt));
    }
    return await db.select().from(deposits).orderBy(desc(deposits.createdAt));
  }

  async approveDeposit(depositId: string): Promise<void> {
    const deposit = await db.select().from(deposits).where(eq(deposits.id, depositId));
    if (!deposit[0]) throw new Error("Deposit not found");

    await db.transaction(async (tx) => {
      await tx
        .update(deposits)
        .set({ status: 'approved' })
        .where(eq(deposits.id, depositId));

      await this.updateUserBalance(deposit[0].userId, parseFloat(deposit[0].amount), 'deposit', 'Deposit approved');
    });
  }

  async rejectDeposit(depositId: string, reason: string): Promise<void> {
    await db
      .update(deposits)
      .set({ status: 'rejected', rejectionReason: reason })
      .where(eq(deposits.id, depositId));
  }

  async createCard(card: { userId: string; cardNumber: string; expiryMonth: string; expiryYear: string; cvv: string; cardholderName: string; cardLimit: string; gpayCardId: string }): Promise<Card> {
    const [newCard] = await db
      .insert(cards)
      .values(card)
      .returning();
    return newCard;
  }

  async getCard(cardId: string): Promise<Card | undefined> {
    const [card] = await db.select().from(cards).where(eq(cards.id, cardId));
    return card || undefined;
  }

  async getUserCards(userId: string): Promise<Card[]> {
    return await db.select().from(cards).where(eq(cards.userId, userId)).orderBy(desc(cards.createdAt));
  }

  async getAllCards(): Promise<Card[]> {
    return await db.select().from(cards).orderBy(desc(cards.createdAt));
  }

  async updateCardBalance(cardId: string, amount: number): Promise<void> {
    const card = await this.getCard(cardId);
    if (!card) throw new Error("Card not found");

    const currentBalance = parseFloat(card.balance);
    const newBalance = currentBalance + amount;

    await db.transaction(async (tx) => {
      await tx
        .update(cards)
        .set({ balance: newBalance.toString() })
        .where(eq(cards.id, cardId));

      await tx.insert(transactions).values({
        userId: card.userId,
        cardId,
        type: 'card_topup',
        amount: amount.toString(),
        description: `Card top-up: ${card.cardNumber.slice(-4)}`,
        balanceBefore: currentBalance.toString(),
        balanceAfter: newBalance.toString(),
      });
    });
  }

  async getUserTransactions(userId: string, limit?: number): Promise<Transaction[]> {
    const query = db.select().from(transactions).where(eq(transactions.userId, userId)).orderBy(desc(transactions.createdAt));
    if (limit) {
      return await query.limit(limit);
    }
    return await query;
  }

  async getCardTransactions(cardId: string, userId: string): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .where(and(eq(transactions.cardId, cardId), eq(transactions.userId, userId)))
      .orderBy(desc(transactions.createdAt));
  }

  async createReferral(referrerId: string, referredUserId: string): Promise<void> {
    await db.insert(referrals).values({
      referrerId,
      referredUserId,
    });
  }

  async getReferralStats(userId: string): Promise<{ totalEarnings: string; totalReferrals: number }> {
    const [stats] = await db
      .select({
        totalEarnings: sql<string>`COALESCE(SUM(${referrals.totalCommissionEarned}), 0)`,
        totalReferrals: sql<number>`COUNT(*)`,
      })
      .from(referrals)
      .where(eq(referrals.referrerId, userId));

    return {
      totalEarnings: stats?.totalEarnings || '0.00',
      totalReferrals: stats?.totalReferrals || 0,
    };
  }

  async getRecentReferrals(userId: string): Promise<Array<{
    id: string;
    username: string;
    createdAt: string;
    commissionEarned: string;
    depositAmount?: string;
  }>> {
    const recentReferrals = await db
      .select({
        id: referrals.id,
        username: users.username,
        createdAt: referrals.createdAt,
        commissionEarned: referrals.totalCommissionEarned,
        referredUserId: referrals.referredUserId,
      })
      .from(referrals)
      .leftJoin(users, eq(referrals.referredUserId, users.id))
      .where(eq(referrals.referrerId, userId))
      .orderBy(desc(referrals.createdAt))
      .limit(10);

    // Get deposit amounts for each referred user to calculate commission context
    const enrichedReferrals = await Promise.all(
      recentReferrals.map(async (referral) => {
        const [depositSum] = await db
          .select({ total: sql<string>`COALESCE(SUM(CAST(${deposits.amount} AS DECIMAL)), 0)` })
          .from(deposits)
          .where(and(eq(deposits.userId, referral.referredUserId), eq(deposits.status, 'approved')));

        return {
          id: referral.id,
          username: referral.username || 'Unknown',
          createdAt: referral.createdAt.toISOString(),
          commissionEarned: referral.commissionEarned || '0.00',
          depositAmount: depositSum?.total || '0.00',
        };
      })
    );

    return enrichedReferrals;
  }

  async getAdminStats(): Promise<{
    totalUsers: number;
    activeCards: number;
    totalVolume: string;
    revenue: string;
    recentActivity: Array<{
      id: string;
      type: string;
      description: string;
      details: string;
      timestamp: string;
    }>;
  }> {
    const [userStats] = await db
      .select({ totalUsers: sql<number>`COUNT(*)` })
      .from(users);

    const [cardStats] = await db
      .select({ activeCards: sql<number>`COUNT(*)` })
      .from(cards)
      .where(eq(cards.status, 'active'));

    const [volumeStats] = await db
      .select({ 
        totalVolume: sql<string>`COALESCE(SUM(CAST(${deposits.amount} AS DECIMAL)), 0)`,
        revenue: sql<string>`COALESCE(SUM(CAST(${deposits.amount} AS DECIMAL)) * 0.03, 0)`
      })
      .from(deposits)
      .where(eq(deposits.status, 'approved'));

    // Get recent activity from multiple sources
    const recentUsers = await db
      .select({
        id: users.id,
        timestamp: users.createdAt,
        username: users.username,
      })
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(5);

    const recentCards = await db
      .select({
        id: cards.id,
        timestamp: cards.createdAt,
        userId: cards.userId,
        cardNumber: cards.cardNumber,
      })
      .from(cards)
      .orderBy(desc(cards.createdAt))
      .limit(5);

    // Combine and format recent activity
    const recentActivity: Array<{
      id: string;
      type: string;
      description: string;
      details: string;
      timestamp: string;
    }> = [
      ...recentUsers.map(user => ({
        id: user.id,
        type: 'user_registration',
        description: 'New user registered',
        details: `User: ${user.username}`,
        timestamp: user.timestamp.toISOString(),
      })),
      ...recentCards.map(card => ({
        id: card.id,
        type: 'card_generation',
        description: 'New card generated',
        details: `Card ending in ${card.cardNumber.slice(-4)}`,
        timestamp: card.timestamp.toISOString(),
      })),
    ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10);

    return {
      totalUsers: userStats?.totalUsers || 0,
      activeCards: cardStats?.activeCards || 0,
      totalVolume: volumeStats?.totalVolume || '0.00',
      revenue: volumeStats?.revenue || '0.00',
      recentActivity,
    };
  }
}

export const storage = new DatabaseStorage();