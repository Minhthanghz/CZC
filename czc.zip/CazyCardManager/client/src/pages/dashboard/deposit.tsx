import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import QRCode from "@/components/ui/qr-code";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertDepositSchema, type InsertDeposit } from "@shared/schema";

interface DepositDetails {
  depositId: string;
  amount: number;
  exactAmount: number;
  walletAddress: string;
  qrCodeData: string;
}

export default function Deposit() {
  const [depositDetails, setDepositDetails] = useState<DepositDetails | null>(null);
  const { toast } = useToast();

  const form = useForm<InsertDeposit>({
    resolver: zodResolver(insertDepositSchema),
    defaultValues: {
      amount: 100,
    },
  });

  const generateDepositMutation = useMutation({
    mutationFn: async (data: InsertDeposit) => {
      const response = await apiRequest("POST", "/api/deposits", data);
      return response.json();
    },
    onSuccess: (data) => {
      setDepositDetails(data);
      toast({
        title: "Deposit details generated",
        description: "Send USDT to the provided address with the exact amount",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to generate deposit",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertDeposit) => {
    generateDepositMutation.mutate(data);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard`,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="button-back">
              <i className="fas fa-arrow-left"></i>
              <span>Back to Dashboard</span>
            </Link>
            <h1 className="text-lg font-semibold">Deposit USDT</h1>
            <div></div>
          </div>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="cyber-card border border-border">
          <CardHeader>
            <CardTitle className="text-center">
              <h2 className="text-2xl font-bold text-foreground mb-2">Deposit USDT-BEP20</h2>
              <p className="text-muted-foreground font-normal">Add funds to your account using USDT on Binance Smart Chain</p>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-6" onSubmit={form.handleSubmit(onSubmit)}>
              <div>
                <Label htmlFor="amount">Deposit Amount (USDT)</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="10"
                  {...form.register("amount", { valueAsNumber: true })}
                  placeholder="100"
                  className="mt-2"
                  data-testid="input-amount"
                />
                <p className="text-xs text-muted-foreground mt-1">Minimum deposit: $10 USDT</p>
                {form.formState.errors.amount && (
                  <p className="text-sm text-destructive mt-1" data-testid="error-amount">
                    {form.formState.errors.amount.message}
                  </p>
                )}
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 text-white hover:shadow-lg transition-all"
                disabled={generateDepositMutation.isPending}
                data-testid="button-generate-deposit"
              >
                {generateDepositMutation.isPending ? "Generating..." : "Generate Deposit Address"}
              </Button>
            </form>

            {/* Deposit Details */}
            {depositDetails && (
              <div className="mt-8 p-6 bg-muted/50 rounded-lg border-2 border-emerald-500/30" data-testid="deposit-details">
                <div className="text-center mb-6">
                  <h3 className="text-lg font-semibold text-foreground mb-2">Deposit Details</h3>
                  <p className="text-sm text-muted-foreground">Send exactly the amount below to complete your deposit</p>
                </div>

                <div className="space-y-4">
                  <div className="text-center">
                    <QRCode
                      value={depositDetails.qrCodeData}
                      size={192}
                      className="mx-auto mb-4"
                      data-testid="qr-code"
                    />
                  </div>

                  <div>
                    <Label>Wallet Address</Label>
                    <div className="flex items-center space-x-2 mt-2">
                      <Input
                        type="text"
                        value={depositDetails.walletAddress}
                        readOnly
                        className="flex-1 bg-muted"
                        data-testid="input-wallet-address"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => copyToClipboard(depositDetails.walletAddress, "Wallet address")}
                        data-testid="button-copy-address"
                      >
                        <i className="fas fa-copy"></i>
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>Exact Amount</Label>
                    <div className="flex items-center space-x-2 mt-2">
                      <Input
                        type="text"
                        value={`$${depositDetails.exactAmount.toFixed(4)} USDT`}
                        readOnly
                        className="flex-1 bg-muted font-mono"
                        data-testid="input-exact-amount"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => copyToClipboard(depositDetails.exactAmount.toString(), "Exact amount")}
                        data-testid="button-copy-amount"
                      >
                        <i className="fas fa-copy"></i>
                      </Button>
                    </div>
                    <p className="text-xs text-destructive mt-1">⚠️ Send exactly this amount including decimals</p>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div className="flex items-start space-x-2">
                      <i className="fas fa-exclamation-triangle text-yellow-600 mt-1"></i>
                      <div className="text-sm text-yellow-800">
                        <p className="font-medium mb-1">Important Notes:</p>
                        <ul className="list-disc list-inside space-y-1">
                          <li>Only send USDT-BEP20 to this address</li>
                          <li>Deposits are manually reviewed and may take 5-30 minutes</li>
                          <li>Minimum deposit is $10 USDT</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
