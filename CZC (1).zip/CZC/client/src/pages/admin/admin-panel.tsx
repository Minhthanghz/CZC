import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { User, Deposit, Card as CardType, Transaction, UserWithStats } from "@shared/schema";

type AdminSection = 'overview' | 'users' | 'deposits' | 'cards' | 'transactions' | 'referrals';

interface AdminStats {
  totalUsers: number;
  activeCards: number;
  totalVolume: string;
  revenue: string;
  recentActivity: Array<{
    id: string;
    type: string;
    description: string;
    details: string;
    timestamp: string;
  }>;
}

export default function AdminPanel() {
  const [activeSection, setActiveSection] = useState<AdminSection>('overview');
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if user is admin
  const { data: user } = useQuery<User>({
    queryKey: ["/api/auth/me"],
  });

  if (user && !user.isAdmin) {
    setLocation("/dashboard");
    return null;
  }

  const { data: stats } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    enabled: activeSection === 'overview',
  });

  const { data: users } = useQuery<UserWithStats[]>({
    queryKey: ["/api/admin/users"],
    enabled: activeSection === 'users',
  });

  const { data: deposits } = useQuery<Deposit[]>({
    queryKey: ["/api/admin/deposits"],
    enabled: activeSection === 'deposits',
  });

  const { data: cards } = useQuery<CardType[]>({
    queryKey: ["/api/admin/cards"],
    enabled: activeSection === 'cards',
  });

  const approveDepositMutation = useMutation({
    mutationFn: async (depositId: string) => {
      const response = await apiRequest("POST", `/api/admin/deposits/${depositId}/approve`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Deposit approved",
        description: "User balance has been updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/deposits"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to approve deposit",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const rejectDepositMutation = useMutation({
    mutationFn: async ({ depositId, reason }: { depositId: string; reason: string }) => {
      const response = await apiRequest("POST", `/api/admin/deposits/${depositId}/reject`, { reason });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Deposit rejected",
        description: "User has been notified",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/deposits"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to reject deposit",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logout = () => {
    localStorage.removeItem("auth_token");
    setLocation("/");
  };

  const renderOverview = () => (
    <div>
      <h1 className="text-3xl font-bold text-foreground mb-8">Dashboard Overview</h1>
      
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <div className="cyber-card rounded-xl p-6 border-2 border-emerald-500/30">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground">Total Users</h3>
            <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-users text-white"></i>
            </div>
          </div>
          <div className="text-3xl font-bold text-foreground" data-testid="stat-total-users">
            {stats?.totalUsers || 0}
          </div>
          <div className="text-sm text-emerald-500">+12% this month</div>
        </div>

        <div className="cyber-card rounded-xl p-6 border-2 border-purple-500/30">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground">Active Cards</h3>
            <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-credit-card text-white"></i>
            </div>
          </div>
          <div className="text-3xl font-bold text-foreground" data-testid="stat-active-cards">
            {stats?.activeCards || 0}
          </div>
          <div className="text-sm text-purple-500">+8% this month</div>
        </div>

        <div className="cyber-card rounded-xl p-6 border-2 border-cyan-500/30">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground">Total Volume</h3>
            <div className="w-10 h-10 bg-cyan-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-dollar-sign text-white"></i>
            </div>
          </div>
          <div className="text-3xl font-bold text-foreground" data-testid="stat-total-volume">
            ${stats?.totalVolume || '0.00'}
          </div>
          <div className="text-sm text-cyan-500">+23% this month</div>
        </div>

        <div className="cyber-card rounded-xl p-6 border-2 border-orange-500/30">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground">Revenue</h3>
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-chart-line text-white"></i>
            </div>
          </div>
          <div className="text-3xl font-bold text-foreground" data-testid="stat-revenue">
            ${stats?.revenue || '0.00'}
          </div>
          <div className="text-sm text-orange-500">+15% this month</div>
        </div>
      </div>

      <Card className="cyber-card border border-border">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4" data-testid="recent-activity">
            {stats?.recentActivity && stats.recentActivity.length > 0 ? (
              stats.recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      activity.type === 'user_registration' ? 'bg-emerald-500' :
                      activity.type === 'card_generation' ? 'bg-purple-500' :
                      'bg-cyan-500'
                    }`}>
                      <i className={`text-white text-xs ${
                        activity.type === 'user_registration' ? 'fas fa-user-plus' :
                        activity.type === 'card_generation' ? 'fas fa-credit-card' :
                        'fas fa-coins'
                      }`}></i>
                    </div>
                    <div>
                      <div className="font-medium text-foreground">{activity.description}</div>
                      <div className="text-sm text-muted-foreground">{activity.details}</div>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {new Date(activity.timestamp).toLocaleString()}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <i className="fas fa-clock text-4xl text-muted-foreground mb-4"></i>
                <p className="text-muted-foreground">No recent activity</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderUsers = () => (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-foreground">User Management</h1>
        <div className="flex items-center space-x-4">
          <Input
            type="text"
            placeholder="Search users..."
            className="w-64"
            data-testid="input-search-users"
          />
          <Button data-testid="button-search-users">
            <i className="fas fa-search mr-2"></i>Search
          </Button>
        </div>
      </div>

      <Card className="cyber-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted">
              <tr>
                <th className="text-left p-4 font-semibold text-foreground">User</th>
                <th className="text-left p-4 font-semibold text-foreground">Email</th>
                <th className="text-left p-4 font-semibold text-foreground">Balance</th>
                <th className="text-left p-4 font-semibold text-foreground">Cards</th>
                <th className="text-left p-4 font-semibold text-foreground">Status</th>
                <th className="text-left p-4 font-semibold text-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users && users.length > 0 ? (
                users.map((user: User) => (
                  <tr key={user.id} className="border-t border-border" data-testid={`user-row-${user.id}`}>
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                          <span className="text-white text-sm font-semibold">
                            {user.username.substring(0, 2).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <div className="font-medium text-foreground">{user.username}</div>
                          <div className="text-sm text-muted-foreground">ID: {user.id.substring(0, 8)}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-foreground">{user.email}</td>
                    <td className="p-4 text-foreground font-medium">${user.balance}</td>
                    <td className="p-4 text-foreground">
                      {cards?.filter((card: CardType) => card.userId === user.id).length || 0}
                    </td>
                    <td className="p-4">
                      <Badge variant="default" data-testid={`user-status-${user.id}`}>
                        Active
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button variant="link" size="sm" data-testid={`button-edit-${user.id}`}>
                          Edit
                        </Button>
                        <Button variant="link" size="sm" className="text-orange-500" data-testid={`button-suspend-${user.id}`}>
                          Suspend
                        </Button>
                        <Button variant="link" size="sm" className="text-red-500" data-testid={`button-ban-${user.id}`}>
                          Ban
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-muted-foreground">
                    No users found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );

  const renderDeposits = () => (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-foreground">Deposit Management</h1>
        <div className="flex items-center space-x-4">
          <Select defaultValue="all">
            <SelectTrigger className="w-48" data-testid="select-deposit-status">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
          <Button data-testid="button-filter-deposits">
            <i className="fas fa-filter mr-2"></i>Filter
          </Button>
        </div>
      </div>

      <Card className="cyber-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted">
              <tr>
                <th className="text-left p-4 font-semibold text-foreground">User</th>
                <th className="text-left p-4 font-semibold text-foreground">Amount</th>
                <th className="text-left p-4 font-semibold text-foreground">Exact Amount</th>
                <th className="text-left p-4 font-semibold text-foreground">Date</th>
                <th className="text-left p-4 font-semibold text-foreground">Status</th>
                <th className="text-left p-4 font-semibold text-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {deposits && deposits.length > 0 ? (
                deposits.map((deposit: Deposit) => {
                  const user = users?.find((u: User) => u.id === deposit.userId);
                  return (
                    <tr key={deposit.id} className="border-t border-border" data-testid={`deposit-row-${deposit.id}`}>
                      <td className="p-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-semibold">
                              {user?.username?.substring(0, 2).toUpperCase() || 'U'}
                            </span>
                          </div>
                          <div>
                            <div className="font-medium text-foreground">{user?.username || 'Unknown'}</div>
                            <div className="text-sm text-muted-foreground">ID: {deposit.userId.substring(0, 8)}</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-foreground font-medium">${deposit.amount}</td>
                      <td className="p-4 text-foreground font-mono text-sm">${deposit.exactAmount}</td>
                      <td className="p-4 text-foreground">
                        {new Date(deposit.createdAt).toLocaleDateString()}
                      </td>
                      <td className="p-4">
                        <Badge 
                          variant={
                            deposit.status === 'approved' ? 'default' :
                            deposit.status === 'pending' ? 'secondary' :
                            'destructive'
                          }
                          data-testid={`deposit-status-${deposit.id}`}
                        >
                          {deposit.status}
                        </Badge>
                      </td>
                      <td className="p-4">
                        {deposit.status === 'pending' ? (
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              className="bg-emerald-500 text-white hover:bg-emerald-600"
                              onClick={() => approveDepositMutation.mutate(deposit.id)}
                              disabled={approveDepositMutation.isPending}
                              data-testid={`button-approve-${deposit.id}`}
                            >
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => {
                                const reason = prompt("Rejection reason:");
                                if (reason) {
                                  rejectDepositMutation.mutate({ depositId: deposit.id, reason });
                                }
                              }}
                              disabled={rejectDepositMutation.isPending}
                              data-testid={`button-reject-${deposit.id}`}
                            >
                              Reject
                            </Button>
                          </div>
                        ) : (
                          <Button variant="link" size="sm" data-testid={`button-view-${deposit.id}`}>
                            View Details
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-muted-foreground">
                    No deposits found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return renderOverview();
      case 'users':
        return renderUsers();
      case 'deposits':
        return renderDeposits();
      case 'cards':
        return <div className="text-center py-12"><p className="text-muted-foreground">Cards management coming soon...</p></div>;
      case 'transactions':
        return <div className="text-center py-12"><p className="text-muted-foreground">Transaction logs coming soon...</p></div>;
      case 'referrals':
        return <div className="text-center py-12"><p className="text-muted-foreground">Referral management coming soon...</p></div>;
      default:
        return renderOverview();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Navigation */}
      <nav className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
                <i className="fas fa-shield-alt text-white text-sm"></i>
              </div>
              <span className="text-xl font-bold">Admin Panel</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <i className="fas fa-bell"></i>
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-semibold">A</span>
                </div>
                <span className="text-foreground font-medium">{user?.username || 'admin'}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={logout} data-testid="button-logout">
                <i className="fas fa-sign-out-alt"></i>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="flex">
        {/* Admin Sidebar */}
        <div className="w-64 bg-card border-r border-border min-h-[calc(100vh-4rem)]">
          <div className="p-6">
            <nav className="space-y-2">
              <button
                onClick={() => setActiveSection('overview')}
                className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-colors ${
                  activeSection === 'overview'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
                data-testid="nav-overview"
              >
                <i className="fas fa-chart-bar mr-3"></i>Overview
              </button>
              <button
                onClick={() => setActiveSection('users')}
                className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-colors ${
                  activeSection === 'users'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
                data-testid="nav-users"
              >
                <i className="fas fa-users mr-3"></i>Users
              </button>
              <button
                onClick={() => setActiveSection('deposits')}
                className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-colors ${
                  activeSection === 'deposits'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
                data-testid="nav-deposits"
              >
                <i className="fas fa-coins mr-3"></i>Deposits
              </button>
              <button
                onClick={() => setActiveSection('cards')}
                className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-colors ${
                  activeSection === 'cards'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
                data-testid="nav-cards"
              >
                <i className="fas fa-credit-card mr-3"></i>Cards
              </button>
              <button
                onClick={() => setActiveSection('transactions')}
                className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-colors ${
                  activeSection === 'transactions'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
                data-testid="nav-transactions"
              >
                <i className="fas fa-exchange-alt mr-3"></i>Transactions
              </button>
              <button
                onClick={() => setActiveSection('referrals')}
                className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-colors ${
                  activeSection === 'referrals'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted'
                }`}
                data-testid="nav-referrals"
              >
                <i className="fas fa-link mr-3"></i>Referrals
              </button>
            </nav>
          </div>
        </div>

        {/* Admin Content */}
        <div className="flex-1 p-8">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}
