import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import VirtualCard from "@/components/cards/virtual-card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertCardSchema, type InsertCard } from "@shared/schema";

interface GeneratedCard {
  cardId: string;
  cardNumber: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: string;
  cardholderName: string;
  balance: string;
  cardLimit: string;
}

export default function GenerateCard() {
  const [generatedCard, setGeneratedCard] = useState<GeneratedCard | null>(null);
  const { toast } = useToast();

  const form = useForm<InsertCard>({
    resolver: zodResolver(insertCardSchema),
    defaultValues: {
      cardholderName: "",
      cardLimit: 100,
    },
  });

  const generateCardMutation = useMutation({
    mutationFn: async (data: InsertCard) => {
      const response = await apiRequest("POST", "/api/cards", data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedCard(data);
      toast({
        title: "Card generated successfully",
        description: "Your virtual card is ready to use",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to generate card",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertCard) => {
    generateCardMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="button-back">
              <i className="fas fa-arrow-left"></i>
              <span>Back to Dashboard</span>
            </Link>
            <h1 className="text-lg font-semibold">Generate Virtual Card</h1>
            <div></div>
          </div>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="cyber-card border border-border">
          <CardHeader>
            <CardTitle className="text-center">
              <h2 className="text-2xl font-bold text-foreground mb-2">Generate New Card</h2>
              <p className="text-muted-foreground font-normal">Create a virtual card for online payments</p>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-6" onSubmit={form.handleSubmit(onSubmit)}>
              <div>
                <Label htmlFor="cardholderName">Cardholder Name</Label>
                <Input
                  id="cardholderName"
                  type="text"
                  {...form.register("cardholderName")}
                  placeholder="John Doe"
                  className="mt-2"
                  data-testid="input-cardholder-name"
                />
                {form.formState.errors.cardholderName && (
                  <p className="text-sm text-destructive mt-1" data-testid="error-cardholder-name">
                    {form.formState.errors.cardholderName.message}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="cardLimit">Card Limit (USD)</Label>
                <Select 
                  onValueChange={(value) => form.setValue("cardLimit", parseInt(value))}
                  defaultValue="100"
                >
                  <SelectTrigger className="mt-2" data-testid="select-card-limit">
                    <SelectValue placeholder="Select card limit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="100">$100</SelectItem>
                    <SelectItem value="500">$500</SelectItem>
                    <SelectItem value="1000">$1,000</SelectItem>
                    <SelectItem value="5000">$5,000</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.cardLimit && (
                  <p className="text-sm text-destructive mt-1" data-testid="error-card-limit">
                    {form.formState.errors.cardLimit.message}
                  </p>
                )}
              </div>

              <div className="bg-muted/50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-foreground font-medium">Card Generation Fee</span>
                  <span className="text-foreground font-semibold">$3.00</span>
                </div>
                <div className="text-sm text-muted-foreground">
                  One-time fee for card creation and activation
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:shadow-lg transition-all"
                disabled={generateCardMutation.isPending}
                data-testid="button-generate-card"
              >
                {generateCardMutation.isPending ? "Generating Card..." : "Generate Card ($3.00)"}
              </Button>
            </form>

            {/* Generated Card Details */}
            {generatedCard && (
              <div className="mt-8" data-testid="generated-card-details">
                <div className="text-center mb-6">
                  <h3 className="text-lg font-semibold text-emerald-500 mb-2">✅ Card Generated Successfully!</h3>
                  <p className="text-sm text-muted-foreground">Your virtual card is ready to use</p>
                </div>

                <div className="mb-6">
                  <VirtualCard
                    cardNumber={generatedCard.cardNumber}
                    cardholderName={generatedCard.cardholderName}
                    expiryMonth={generatedCard.expiryMonth}
                    expiryYear={generatedCard.expiryYear}
                    cvv={generatedCard.cvv}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Button className="bg-emerald-500 text-white hover:bg-emerald-600 transition-colors" data-testid="button-load-funds">
                    <i className="fas fa-plus mr-2"></i>Load Funds
                  </Button>
                  <Link href="/cards">
                    <Button variant="outline" className="w-full" data-testid="button-manage-cards">
                      <i className="fas fa-cog mr-2"></i>Manage Cards
                    </Button>
                  </Link>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
