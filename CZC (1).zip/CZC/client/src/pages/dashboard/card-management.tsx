import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Card as CardType, Transaction } from "@shared/schema";

export default function CardManagement() {
  const { data: cards, isLoading: cardsLoading } = useQuery<CardType[]>({
    queryKey: ["/api/cards"],
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  if (cardsLoading || transactionsLoading) {
    return (
      <div className="min-h-screen bg-background">
        <nav className="bg-card border-b border-border shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <Link href="/dashboard" className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors">
                <i className="fas fa-arrow-left"></i>
                <span>Back to Dashboard</span>
              </Link>
              <h1 className="text-lg font-semibold">Card Management</h1>
              <div></div>
            </div>
          </div>
        </nav>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse grid lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              {[1, 2].map((i) => (
                <div key={i} className="h-48 bg-muted rounded-xl"></div>
              ))}
            </div>
            <div className="h-96 bg-muted rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  const cardTransactions = transactions?.filter((t: Transaction) => t.cardId) || [];

  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="button-back">
              <i className="fas fa-arrow-left"></i>
              <span>Back to Dashboard</span>
            </Link>
            <h1 className="text-lg font-semibold">Card Management</h1>
            <Link href="/generate-card">
              <Button data-testid="button-new-card">
                <i className="fas fa-plus mr-2"></i>New Card
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Active Cards */}
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-foreground">Active Cards</h2>
            
            {cards && cards.length > 0 ? (
              cards.map((card: CardType) => (
                <Card key={card.id} className="cyber-card border border-border" data-testid={`card-${card.id}`}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="text-sm text-muted-foreground">Card ending in</div>
                        <div className="font-mono text-lg font-semibold text-foreground">
                          •••• {card.cardNumber.slice(-4)}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline" data-testid={`button-topup-${card.id}`}>
                          <i className="fas fa-plus text-xs"></i>
                        </Button>
                        <Button size="sm" variant="outline" data-testid={`button-view-${card.id}`}>
                          <i className="fas fa-eye text-xs"></i>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Balance:</span>
                        <span className="font-semibold text-foreground" data-testid={`balance-${card.id}`}>
                          ${card.balance}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Limit:</span>
                        <span className="font-semibold text-foreground">${card.cardLimit}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Status:</span>
                        <Badge 
                          variant={card.status === 'active' ? 'default' : 'secondary'}
                          data-testid={`status-${card.id}`}
                        >
                          {card.status}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Created:</span>
                        <span className="text-foreground">
                          {new Date(card.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-border">
                      <Button className="w-full bg-gradient-to-r from-emerald-500 to-cyan-500 text-white hover:shadow-lg transition-all" data-testid={`button-load-funds-${card.id}`}>
                        Load Funds
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="cyber-card border border-border">
                <CardContent className="p-8 text-center">
                  <i className="fas fa-credit-card text-4xl text-muted-foreground mb-4"></i>
                  <p className="text-muted-foreground mb-2">No cards yet</p>
                  <p className="text-sm text-muted-foreground mb-4">Generate your first virtual card to get started</p>
                  <Link href="/generate-card">
                    <Button data-testid="button-generate-first-card">
                      <i className="fas fa-plus mr-2"></i>Generate Card
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Transaction History */}
          <div>
            <h2 className="text-xl font-semibold text-foreground mb-6">Transaction History</h2>
            
            <Card className="cyber-card border border-border">
              <CardHeader>
                <CardTitle>Card Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4" data-testid="card-transactions-list">
                  {cardTransactions.length > 0 ? (
                    cardTransactions.map((transaction: Transaction) => (
                      <div key={transaction.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg" data-testid={`transaction-${transaction.id}`}>
                        <div className="flex items-center space-x-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                            transaction.type === 'card_topup' ? 'bg-emerald-500' :
                            transaction.type === 'purchase' ? 'bg-red-500' :
                            'bg-blue-500'
                          }`}>
                            <i className={`text-white ${
                              transaction.type === 'card_topup' ? 'fas fa-arrow-down' :
                              transaction.type === 'purchase' ? 'fas fa-shopping-cart' :
                              'fas fa-exchange-alt'
                            }`}></i>
                          </div>
                          <div>
                            <div className="font-medium text-foreground">{transaction.description}</div>
                            <div className="text-sm text-muted-foreground">
                              {transaction.cardId && `•••• ${cards?.find((c: CardType) => c.id === transaction.cardId)?.cardNumber?.slice(-4) || '****'}`}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {new Date(transaction.createdAt).toLocaleDateString()} at {new Date(transaction.createdAt).toLocaleTimeString()}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`font-semibold ${
                            parseFloat(transaction.amount) > 0 ? 'text-emerald-500' : 'text-red-500'
                          }`}>
                            {parseFloat(transaction.amount) > 0 ? '+' : ''}${transaction.amount}
                          </div>
                          <div className="text-xs text-muted-foreground">Completed</div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8" data-testid="empty-card-transactions">
                      <i className="fas fa-receipt text-4xl text-muted-foreground mb-4"></i>
                      <p className="text-muted-foreground">No card transactions yet</p>
                      <p className="text-sm text-muted-foreground">Card transaction history will appear here</p>
                    </div>
                  )}
                </div>

                {cardTransactions.length > 0 && (
                  <div className="mt-6 text-center">
                    <Button variant="link" className="text-primary hover:underline" data-testid="button-view-all-transactions">
                      View All Transactions
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
