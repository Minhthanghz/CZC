import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import DashboardNavbar from "@/components/dashboard/navbar";
import StatsCard from "@/components/dashboard/stats-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Transaction } from "@shared/schema";

interface DashboardStats {
  balance: string;
  activeCards: number;
  referralEarnings: string;
  recentTransactions: Transaction[];
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <DashboardNavbar />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-8">
            <div className="grid md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-muted rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Manage your virtual cards and transactions</p>
        </div>

        {/* Balance Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <StatsCard
            title="Account Balance"
            value={`$${stats?.balance || '0.00'}`}
            change="+5.2% from last month"
            icon="wallet"
            color="emerald"
            data-testid="card-balance"
          />
          
          <StatsCard
            title="Active Cards"
            value={stats?.activeCards?.toString() || '0'}
            change="2 pending approval"
            icon="credit-card"
            color="purple"
            data-testid="card-active-cards"
          />
          
          <StatsCard
            title="Referral Earnings"
            value={`$${stats?.referralEarnings || '0.00'}`}
            change="8 referrals this month"
            icon="users"
            color="cyan"
            data-testid="card-referral-earnings"
          />
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Link href="/deposit">
            <div className="cyber-card rounded-xl p-6 text-center hover:scale-105 transition-all border-2 border-emerald-500/30 hover:border-emerald-500 cursor-pointer" data-testid="button-deposit-funds">
              <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-plus text-white text-lg"></i>
              </div>
              <div className="font-semibold text-foreground">Deposit Funds</div>
              <div className="text-sm text-muted-foreground">Add USDT to account</div>
            </div>
          </Link>

          <Link href="/generate-card">
            <div className="cyber-card rounded-xl p-6 text-center hover:scale-105 transition-all border-2 border-purple-500/30 hover:border-purple-500 cursor-pointer" data-testid="button-generate-card">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-credit-card text-white text-lg"></i>
              </div>
              <div className="font-semibold text-foreground">Generate Card</div>
              <div className="text-sm text-muted-foreground">Create new virtual card</div>
            </div>
          </Link>

          <Link href="/cards">
            <div className="cyber-card rounded-xl p-6 text-center hover:scale-105 transition-all border-2 border-cyan-500/30 hover:border-cyan-500 cursor-pointer" data-testid="button-manage-cards">
              <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-cog text-white text-lg"></i>
              </div>
              <div className="font-semibold text-foreground">Manage Cards</div>
              <div className="text-sm text-muted-foreground">View and control cards</div>
            </div>
          </Link>

          <Link href="/referral">
            <div className="cyber-card rounded-xl p-6 text-center hover:scale-105 transition-all border-2 border-orange-500/30 hover:border-orange-500 cursor-pointer" data-testid="button-referral-link">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-link text-white text-lg"></i>
              </div>
              <div className="font-semibold text-foreground">Referral Link</div>
              <div className="text-sm text-muted-foreground">Share and earn</div>
            </div>
          </Link>
        </div>

        {/* Recent Transactions */}
        <Card className="cyber-card border border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-semibold text-foreground">Recent Transactions</CardTitle>
              <Button variant="link" className="text-primary hover:underline" data-testid="button-view-all">
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4" data-testid="transactions-list">
              {stats?.recentTransactions && stats.recentTransactions.length > 0 ? (
                stats.recentTransactions.map((transaction: Transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg" data-testid={`transaction-${transaction.id}`}>
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        transaction.type === 'deposit' ? 'bg-emerald-500' :
                        transaction.type === 'card_generation' ? 'bg-purple-500' :
                        transaction.type === 'referral_commission' ? 'bg-cyan-500' : 'bg-gray-500'
                      }`}>
                        <i className={`text-white ${
                          transaction.type === 'deposit' ? 'fas fa-arrow-down' :
                          transaction.type === 'card_generation' ? 'fas fa-credit-card' :
                          transaction.type === 'referral_commission' ? 'fas fa-users' : 'fas fa-exchange-alt'
                        }`}></i>
                      </div>
                      <div>
                        <div className="font-medium text-foreground">{transaction.description}</div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(transaction.createdAt).toLocaleDateString()} at {new Date(transaction.createdAt).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`font-semibold ${
                        parseFloat(transaction.amount) > 0 ? 'text-emerald-500' : 'text-red-500'
                      }`}>
                        {parseFloat(transaction.amount) > 0 ? '+' : ''}${transaction.amount}
                      </div>
                      <div className="text-sm text-muted-foreground">Completed</div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8" data-testid="empty-transactions">
                  <i className="fas fa-receipt text-4xl text-muted-foreground mb-4"></i>
                  <p className="text-muted-foreground">No transactions yet</p>
                  <p className="text-sm text-muted-foreground">Your transaction history will appear here</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
