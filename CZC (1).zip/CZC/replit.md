# Cazycard Platform

## Overview

Cazycard is a comprehensive virtual card generation and balance management platform that replicates BingCard's functionality with modern web technologies. The platform enables users to create virtual payment cards funded through USDT cryptocurrency deposits, manage balances, and track transactions. It features a full-stack architecture with React frontend, Express.js backend, PostgreSQL database, and integrates with external card generation services and blockchain networks.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui design system for consistent, accessible components
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **Form Handling**: React Hook Form with Zod validation for robust form management

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API development
- **Language**: TypeScript for type safety across the entire stack
- **Authentication**: JWT-based authentication with bcrypt for password hashing
- **Middleware**: Custom authentication and authorization middleware for route protection
- **API Design**: RESTful endpoints organized by feature domains (auth, cards, deposits, etc.)

### Database Design
- **Database**: PostgreSQL for ACID compliance and complex queries
- **ORM**: Drizzle ORM for type-safe database operations and migrations
- **Connection**: Neon serverless PostgreSQL with connection pooling for scalability
- **Schema**: Normalized relational design with proper foreign key relationships between users, cards, deposits, transactions, and referrals

### Authentication & Authorization
- **Strategy**: JWT token-based authentication stored in localStorage
- **Password Security**: bcrypt hashing with salt rounds for secure password storage
- **Role-Based Access**: Admin role system for administrative functions
- **2FA Support**: Google Authenticator integration for enhanced security (schema prepared)
- **Session Management**: Token-based sessions with configurable expiration

### Card Generation System
- **Provider**: GPayCard API integration for virtual card creation
- **Card Types**: Virtual payment cards with standard card details (number, CVV, expiry)
- **Balance Management**: Real-time balance tracking and transaction logging
- **Limits**: Configurable card limits based on user deposits and requirements

### Payment Processing
- **Cryptocurrency**: USDT (BEP-20) deposits via Binance Smart Chain
- **Wallet Integration**: Web3.js for blockchain interaction and transaction monitoring
- **Deposit Verification**: Automated deposit detection and manual approval system
- **Balance Updates**: Atomic balance operations with transaction history

### Business Logic
- **Referral System**: Multi-level referral tracking with commission calculations
- **Transaction Logging**: Comprehensive audit trail for all financial operations
- **Admin Panel**: Full administrative interface for user and transaction management
- **Deposit Management**: Approval workflow for cryptocurrency deposits

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL serverless database connectivity
- **drizzle-orm**: Type-safe ORM for database operations and migrations
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight React routing library
- **@radix-ui/react-***: Accessible UI primitive components
- **tailwindcss**: Utility-first CSS framework

### Authentication & Security
- **jsonwebtoken**: JWT token generation and verification
- **bcrypt**: Password hashing and verification
- **zod**: Runtime type validation and schema definition

### External Service Integrations
- **GPayCard API**: Third-party virtual card generation service
- **Binance Smart Chain**: Blockchain network for USDT deposit processing
- **Web3.js**: Ethereum-compatible blockchain interaction library

### Development & Build Tools
- **vite**: Fast build tool and development server
- **typescript**: Static type checking and enhanced developer experience
- **esbuild**: Fast JavaScript bundler for production builds
- **tsx**: TypeScript execution for development

### UI & Styling
- **class-variance-authority**: Type-safe CSS class variant management
- **clsx**: Conditional CSS class name utility
- **tailwind-merge**: Tailwind class merging utility
- **lucide-react**: Modern icon library

### Form & Data Handling
- **react-hook-form**: Performant form library with validation
- **@hookform/resolvers**: Form validation resolvers
- **axios**: HTTP client for API requests
- **nanoid**: URL-safe unique ID generation