import Web3 from 'web3';

interface DepositMonitorOptions {
  walletAddress: string;
  expectedAmount: number;
  callback: (transactionHash: string, amount: number) => void;
}

export class BlockchainService {
  private web3: Web3;
  private usdtContractAddress = '0x55d398326f99059fF775485246999027B3197955'; // USDT-BEP20
  private monitoringWallet = '0x463f5d4c8a62403a0a28a60712347ae215dab39c';

  constructor() {
    // Initialize Web3 with BSC RPC endpoint
    this.web3 = new Web3('https://bsc-dataseed1.binance.org/');
  }

  async getUSDTBalance(address: string): Promise<number> {
    try {
      // USDT contract ABI for balanceOf function
      const usdtAbi = [
        {
          constant: true,
          inputs: [{ name: '_owner', type: 'address' }],
          name: 'balanceOf',
          outputs: [{ name: 'balance', type: 'uint256' }],
          type: 'function',
        },
      ];

      const contract = new this.web3.eth.Contract(usdtAbi, this.usdtContractAddress);
      const balance = await contract.methods.balanceOf(address).call();
      
      // USDT has 18 decimals - handle potential undefined values
      const balanceString = balance ? balance.toString() : '0';
      return parseFloat(this.web3.utils.fromWei(balanceString, 'ether'));
    } catch (error) {
      console.error('Error getting USDT balance:', error);
      throw new Error('Failed to retrieve USDT balance');
    }
  }

  async monitorDeposit(options: DepositMonitorOptions): Promise<void> {
    const { walletAddress, expectedAmount, callback } = options;
    
    try {
      // Monitor for incoming USDT transactions
      const latestBlock = await this.web3.eth.getBlockNumber();
      const startBlock = Number(latestBlock) - 100; // Check last 100 blocks
      
      // Get USDT transfer events to our wallet
      const transferEventSignature = this.web3.utils.sha3('Transfer(address,address,uint256)');
      
      const logs = await this.web3.eth.getPastLogs({
        fromBlock: startBlock,
        toBlock: 'latest',
        address: this.usdtContractAddress,
        topics: [
          transferEventSignature!,
          null, // from address
          this.web3.utils.padLeft(walletAddress, 64), // to address (our wallet)
        ],
      });

      for (const log of logs) {
        if (typeof log !== 'string' && log.data && log.transactionHash) {
          const amount = parseFloat(this.web3.utils.fromWei(log.data, 'ether'));
          
          // Check if amount matches expected amount (with small tolerance)
          const tolerance = 0.001;
          if (Math.abs(amount - expectedAmount) < tolerance) {
            callback(log.transactionHash, amount);
            break;
          }
        }
      }
    } catch (error) {
      console.error('Error monitoring deposit:', error);
      throw new Error('Failed to monitor blockchain deposit');
    }
  }

  async verifyTransaction(transactionHash: string): Promise<{
    isValid: boolean;
    amount: number;
    toAddress: string;
    fromAddress: string;
  }> {
    try {
      const transaction = await this.web3.eth.getTransaction(transactionHash);
      const receipt = await this.web3.eth.getTransactionReceipt(transactionHash);
      
      if (!transaction || !receipt || !receipt.status) {
        return {
          isValid: false,
          amount: 0,
          toAddress: '',
          fromAddress: '',
        };
      }

      // Decode USDT transfer from transaction logs
      const transferLog = receipt.logs.find(log => 
        log.address && log.address.toLowerCase() === this.usdtContractAddress.toLowerCase()
      );

      if (!transferLog) {
        return {
          isValid: false,
          amount: 0,
          toAddress: '',
          fromAddress: '',
        };
      }

      const amount = parseFloat(this.web3.utils.fromWei(transferLog.data || '0', 'ether'));
      const toAddress = transferLog.topics && transferLog.topics[2] ? '0x' + transferLog.topics[2].slice(26) : '';
      const fromAddress = transferLog.topics && transferLog.topics[1] ? '0x' + transferLog.topics[1].slice(26) : '';

      return {
        isValid: toAddress.toLowerCase() === this.monitoringWallet.toLowerCase(),
        amount,
        toAddress,
        fromAddress,
      };
    } catch (error) {
      console.error('Error verifying transaction:', error);
      return {
        isValid: false,
        amount: 0,
        toAddress: '',
        fromAddress: '',
      };
    }
  }

  generateQRCodeData(amount: number): string {
    return `${this.monitoringWallet}?amount=${amount}`;
  }
}
