import axios from 'axios';

interface CreateCardRequest {
  cardholderName: string;
  cardLimit: number;
}

interface CardResponse {
  id: string;
  cardNumber: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: string;
  status: string;
}

export class GPayCardService {
  private readonly apiKey = 'zJZPahQIQuKZQARlxCigLw==';
  private readonly baseUrl = 'https://api.gpaycard.world';

  async createCard(data: CreateCardRequest): Promise<CardResponse> {
    try {
      const response = await axios.post(`${this.baseUrl}/cards`, {
        cardholderName: data.cardholderName,
        cardLimit: data.cardLimit,
        currency: 'USD',
      }, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.data.success) {
        return {
          id: response.data.card.id,
          cardNumber: response.data.card.number,
          expiryMonth: response.data.card.expiry_month,
          expiryYear: response.data.card.expiry_year,
          cvv: response.data.card.cvv,
          status: response.data.card.status,
        };
      } else {
        throw new Error(response.data.message || 'Card creation failed');
      }
    } catch (error: any) {
      console.error('GPayCard API Error:', error.response?.data || error.message);
      throw new Error('Failed to create card. Please try again.');
    }
  }

  async getCard(cardId: string): Promise<CardResponse> {
    try {
      const response = await axios.get(`${this.baseUrl}/cards/${cardId}`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
        },
      });

      if (response.data.success) {
        return {
          id: response.data.card.id,
          cardNumber: response.data.card.number,
          expiryMonth: response.data.card.expiry_month,
          expiryYear: response.data.card.expiry_year,
          cvv: response.data.card.cvv,
          status: response.data.card.status,
        };
      } else {
        throw new Error(response.data.message || 'Failed to retrieve card');
      }
    } catch (error: any) {
      console.error('GPayCard API Error:', error.response?.data || error.message);
      throw new Error('Failed to retrieve card information');
    }
  }

  async freezeCard(cardId: string): Promise<void> {
    try {
      const response = await axios.post(`${this.baseUrl}/cards/${cardId}/freeze`, {}, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
        },
      });

      if (!response.data.success) {
        throw new Error(response.data.message || 'Failed to freeze card');
      }
    } catch (error: any) {
      console.error('GPayCard API Error:', error.response?.data || error.message);
      throw new Error('Failed to freeze card');
    }
  }

  async unfreezeCard(cardId: string): Promise<void> {
    try {
      const response = await axios.post(`${this.baseUrl}/cards/${cardId}/unfreeze`, {}, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
        },
      });

      if (!response.data.success) {
        throw new Error(response.data.message || 'Failed to unfreeze card');
      }
    } catch (error: any) {
      console.error('GPayCard API Error:', error.response?.data || error.message);
      throw new Error('Failed to unfreeze card');
    }
  }
}
