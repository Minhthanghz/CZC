import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import StatsCard from "@/components/dashboard/stats-card";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

interface ReferralStats {
  totalEarnings: string;
  totalReferrals: number;
}

interface ReferralData {
  stats: ReferralStats;
  recentReferrals: Array<{
    id: string;
    username: string;
    createdAt: string;
    commissionEarned: string;
    depositAmount?: string;
  }>;
}

export default function Referral() {
  const { toast } = useToast();
  
  const { data: referralData, isLoading } = useQuery<ReferralData>({
    queryKey: ["/api/referrals"],
  });

  const { data: user } = useQuery<User>({
    queryKey: ["/api/auth/me"],
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  const shareOn = (platform: string) => {
    const url = `${window.location.origin}/register?ref=${user?.referralCode}`;
    const text = "Join Cazycard and get instant virtual cards with USDT deposits!";
    
    let shareUrl = "";
    switch (platform) {
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
        break;
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case "whatsapp":
        shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text + " " + url)}`;
        break;
      case "email":
        shareUrl = `mailto:?subject=${encodeURIComponent("Join Cazycard")}&body=${encodeURIComponent(text + "\n\n" + url)}`;
        break;
    }
    
    if (shareUrl) {
      window.open(shareUrl, "_blank");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <nav className="bg-card border-b border-border shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <Link href="/dashboard" className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors">
                <i className="fas fa-arrow-left"></i>
                <span>Back to Dashboard</span>
              </Link>
              <h1 className="text-lg font-semibold">Referral Program</h1>
              <div></div>
            </div>
          </div>
        </nav>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-8">
            <div className="grid md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-muted rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const referralLink = `${window.location.origin}/register?ref=${user?.referralCode}`;

  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/dashboard" className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="button-back">
              <i className="fas fa-arrow-left"></i>
              <span>Back to Dashboard</span>
            </Link>
            <h1 className="text-lg font-semibold">Referral Program</h1>
            <div></div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Referral Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <StatsCard
            title="Total Earnings"
            value={`$${referralData?.stats?.totalEarnings || '0.00'}`}
            change="0.1% per referral deposit"
            icon="dollar-sign"
            color="emerald"
            data-testid="card-total-earnings"
          />
          
          <StatsCard
            title="Total Referrals"
            value={referralData?.stats?.totalReferrals?.toString() || '0'}
            change="+8 this month"
            icon="users"
            color="purple"
            data-testid="card-total-referrals"
          />
          
          <StatsCard
            title="Conversion Rate"
            value="68%"
            change="Above average"
            icon="chart-line"
            color="cyan"
            data-testid="card-conversion-rate"
          />
        </div>

        {/* Referral Link */}
        <Card className="cyber-card border border-border mb-8">
          <CardHeader>
            <CardTitle className="text-center">
              <h2 className="text-2xl font-bold text-foreground mb-2">Your Referral Link</h2>
              <p className="text-muted-foreground font-normal">Share this link and earn 0.1% commission on every deposit</p>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label>Referral URL</Label>
                <div className="flex items-center space-x-2 mt-2">
                  <Input
                    type="text"
                    value={referralLink}
                    readOnly
                    className="flex-1 bg-muted font-mono"
                    data-testid="input-referral-link"
                  />
                  <Button
                    onClick={() => copyToClipboard(referralLink)}
                    data-testid="button-copy-link"
                  >
                    <i className="fas fa-copy mr-2"></i>Copy
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button 
                  onClick={() => shareOn("twitter")} 
                  className="bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                  data-testid="button-share-twitter"
                >
                  <i className="fab fa-twitter mr-2"></i>Twitter
                </Button>
                <Button 
                  onClick={() => shareOn("facebook")} 
                  className="bg-blue-800 text-white hover:bg-blue-900 transition-colors"
                  data-testid="button-share-facebook"
                >
                  <i className="fab fa-facebook mr-2"></i>Facebook
                </Button>
                <Button 
                  onClick={() => shareOn("whatsapp")} 
                  className="bg-green-600 text-white hover:bg-green-700 transition-colors"
                  data-testid="button-share-whatsapp"
                >
                  <i className="fab fa-whatsapp mr-2"></i>WhatsApp
                </Button>
                <Button 
                  onClick={() => shareOn("email")} 
                  className="bg-gray-800 text-white hover:bg-gray-900 transition-colors"
                  data-testid="button-share-email"
                >
                  <i className="fas fa-envelope mr-2"></i>Email
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Referrals */}
        <Card className="cyber-card border border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Referrals</CardTitle>
              <Button variant="link" className="text-primary hover:underline" data-testid="button-view-all-referrals">
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4" data-testid="referrals-list">
              {referralData?.recentReferrals && referralData.recentReferrals.length > 0 ? (
                referralData.recentReferrals.map((referral) => (
                  <div key={referral.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg" data-testid={`referral-${referral.id}`}>
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm font-semibold">
                          {referral.username?.substring(0, 2).toUpperCase() || 'U'}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium text-foreground">{referral.username}</div>
                        <div className="text-sm text-muted-foreground">
                          Joined {new Date(referral.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-emerald-500">
                        +${referral.commissionEarned || '0.00'}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        From ${referral.depositAmount || '0'} deposit
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8" data-testid="empty-referrals">
                  <i className="fas fa-users text-4xl text-muted-foreground mb-4"></i>
                  <p className="text-muted-foreground">No referrals yet</p>
                  <p className="text-sm text-muted-foreground">Share your referral link to start earning commissions</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
