interface VirtualCardProps {
  cardNumber: string;
  cardholderName: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: string;
  className?: string;
  'data-testid'?: string;
}

export default function VirtualCard({
  cardNumber,
  cardholderName,
  expiryMonth,
  expiryYear,
  cvv,
  className = "",
  'data-testid': testId
}: VirtualCardProps) {
  
  const formatCardNumber = (number: string) => {
    // Format as XXXX XXXX XXXX XXXX
    return number.replace(/(.{4})/g, '$1 ').trim();
  };

  const maskCardNumber = (number: string) => {
    // Show first 4 and last 4 digits
    const formatted = formatCardNumber(number);
    const parts = formatted.split(' ');
    if (parts.length === 4) {
      return `${parts[0]} •••• •••• ${parts[3]}`;
    }
    return formatted;
  };

  return (
    <div 
      className={`bg-gradient-to-br from-gray-900 to-blue-900 rounded-2xl p-6 text-white shadow-2xl transform hover:scale-105 transition-all duration-300 ${className}`}
      data-testid={testId}
    >
      <div className="flex justify-between items-start mb-8">
        <div>
          <div className="text-sm opacity-75">CAZYCARD</div>
          <div className="text-lg font-bold">VIRTUAL</div>
        </div>
        <div className="w-12 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded"></div>
      </div>
      
      <div className="space-y-4">
        <div className="font-mono text-lg tracking-wider" data-testid="card-number">
          {maskCardNumber(cardNumber)}
        </div>
        
        <div className="flex justify-between items-end">
          <div>
            <div className="text-xs opacity-75">VALID THRU</div>
            <div className="text-sm" data-testid="card-expiry">
              {expiryMonth}/{expiryYear}
            </div>
          </div>
          <div>
            <div className="text-xs opacity-75">CVV</div>
            <div className="text-sm" data-testid="card-cvv">
              {cvv}
            </div>
          </div>
        </div>
        
        <div>
          <div className="text-xs opacity-75">CARDHOLDER</div>
          <div className="text-sm" data-testid="card-name">
            {cardholderName.toUpperCase()}
          </div>
        </div>
      </div>
    </div>
  );
}
