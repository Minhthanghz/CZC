import { useEffect, useRef } from 'react';

interface QRCodeProps {
  value: string;
  size?: number;
  className?: string;
  'data-testid'?: string;
}

export default function QRCode({ value, size = 128, className = "", "data-testid": testId }: QRCodeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Simple QR code placeholder implementation
    // In a real app, you would use a library like 'qrcode' or 'qr-code-generator'
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, size);

    // Draw a simple pattern to represent QR code
    ctx.fillStyle = '#000000';
    const cellSize = size / 25;
    
    // Create a simple pattern
    for (let i = 0; i < 25; i++) {
      for (let j = 0; j < 25; j++) {
        // Simple pattern based on value hash and position
        const hash = value.split('').reduce((a, b) => {
          a = ((a << 5) - a) + b.charCodeAt(0);
          return a & a;
        }, 0);
        
        if ((hash + i * j) % 3 === 0) {
          ctx.fillRect(i * cellSize, j * cellSize, cellSize, cellSize);
        }
      }
    }

    // Draw corner squares (QR code positioning markers)
    const cornerSize = cellSize * 7;
    
    // Top-left corner
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, cornerSize, cornerSize);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(cellSize, cellSize, cornerSize - 2 * cellSize, cornerSize - 2 * cellSize);
    ctx.fillStyle = '#000000';
    ctx.fillRect(2 * cellSize, 2 * cellSize, cornerSize - 4 * cellSize, cornerSize - 4 * cellSize);

    // Top-right corner
    ctx.fillStyle = '#000000';
    ctx.fillRect(size - cornerSize, 0, cornerSize, cornerSize);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(size - cornerSize + cellSize, cellSize, cornerSize - 2 * cellSize, cornerSize - 2 * cellSize);
    ctx.fillStyle = '#000000';
    ctx.fillRect(size - cornerSize + 2 * cellSize, 2 * cellSize, cornerSize - 4 * cellSize, cornerSize - 4 * cellSize);

    // Bottom-left corner
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, size - cornerSize, cornerSize, cornerSize);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(cellSize, size - cornerSize + cellSize, cornerSize - 2 * cellSize, cornerSize - 2 * cellSize);
    ctx.fillStyle = '#000000';
    ctx.fillRect(2 * cellSize, size - cornerSize + 2 * cellSize, cornerSize - 4 * cellSize, cornerSize - 4 * cellSize);

  }, [value, size]);

  return (
    <div className={`inline-block border-2 border-emerald-500 rounded-lg ${className}`} data-testid={testId}>
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="block"
      />
    </div>
  );
}
