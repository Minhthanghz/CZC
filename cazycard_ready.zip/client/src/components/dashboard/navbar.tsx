import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import type { User } from "@shared/schema";

export default function DashboardNavbar() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/auth/me"],
  });

  const logout = () => {
    localStorage.removeItem("auth_token");
    window.location.href = "/";
  };

  const getInitials = (username: string) => {
    return username.substring(0, 2).toUpperCase();
  };

  return (
    <nav className="bg-card border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-credit-card text-white text-sm"></i>
            </div>
            <span className="text-xl font-bold">Cazycard</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" data-testid="button-notifications">
              <i className="fas fa-bell"></i>
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-semibold" data-testid="user-initials">
                  {user?.username ? getInitials(user.username) : 'U'}
                </span>
              </div>
              <span className="text-foreground font-medium" data-testid="user-username">
                {user?.username || 'User'}
              </span>
            </div>
            <Button variant="ghost" size="sm" onClick={logout} data-testid="button-logout">
              <i className="fas fa-sign-out-alt"></i>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
