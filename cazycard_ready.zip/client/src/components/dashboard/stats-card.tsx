import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string;
  change: string;
  icon: string;
  color: 'emerald' | 'purple' | 'cyan' | 'orange';
  className?: string;
  'data-testid'?: string;
}

const colorClasses = {
  emerald: {
    border: 'border-emerald-500/30 hover:border-emerald-500',
    icon: 'bg-gradient-to-r from-emerald-500 to-cyan-500',
    text: 'text-emerald-500'
  },
  purple: {
    border: 'border-purple-500/30 hover:border-purple-500',
    icon: 'bg-gradient-to-r from-purple-500 to-pink-500',
    text: 'text-purple-500'
  },
  cyan: {
    border: 'border-cyan-500/30 hover:border-cyan-500',
    icon: 'bg-gradient-to-r from-cyan-500 to-blue-500',
    text: 'text-cyan-500'
  },
  orange: {
    border: 'border-orange-500/30 hover:border-orange-500',
    icon: 'bg-gradient-to-r from-orange-500 to-red-500',
    text: 'text-orange-500'
  }
};

const iconMap: Record<string, string> = {
  wallet: 'fas fa-wallet',
  'credit-card': 'fas fa-credit-card',
  users: 'fas fa-users',
  'dollar-sign': 'fas fa-dollar-sign',
  'chart-line': 'fas fa-chart-line'
};

export default function StatsCard({ 
  title, 
  value, 
  change, 
  icon, 
  color, 
  className,
  'data-testid': testId 
}: StatsCardProps) {
  const colors = colorClasses[color];
  
  return (
    <div 
      className={cn(
        "cyber-card rounded-xl p-6 border-2 transition-all",
        colors.border,
        className
      )}
      data-testid={testId}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", colors.icon)}>
          <i className={cn("text-white", iconMap[icon] || icon)}></i>
        </div>
      </div>
      <div className="text-3xl font-bold text-foreground mb-2" data-testid={`${testId}-value`}>
        {value}
      </div>
      <div className={cn("text-sm", colors.text)} data-testid={`${testId}-change`}>
        {change}
      </div>
    </div>
  );
}
