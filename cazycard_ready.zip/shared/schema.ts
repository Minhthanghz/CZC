import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const depositStatusEnum = pgEnum('deposit_status', ['pending', 'approved', 'rejected']);
export const cardStatusEnum = pgEnum('card_status', ['active', 'frozen', 'expired']);
export const transactionTypeEnum = pgEnum('transaction_type', ['deposit', 'card_generation', 'card_topup', 'purchase', 'referral_commission', 'manual_adjustment']);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  balance: decimal("balance", { precision: 10, scale: 2 }).notNull().default('0.00'),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: varchar("referred_by"),
  isAdmin: boolean("is_admin").notNull().default(false),
  twoFactorEnabled: boolean("two_factor_enabled").notNull().default(false),
  twoFactorSecret: text("two_factor_secret"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Deposits table
export const deposits = pgTable("deposits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  exactAmount: decimal("exact_amount", { precision: 10, scale: 4 }).notNull(),
  walletAddress: text("wallet_address").notNull(),
  transactionHash: text("transaction_hash"),
  status: depositStatusEnum("status").notNull().default('pending'),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Cards table
export const cards = pgTable("cards", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  cardNumber: text("card_number").notNull(),
  expiryMonth: text("expiry_month").notNull(),
  expiryYear: text("expiry_year").notNull(),
  cvv: text("cvv").notNull(),
  cardholderName: text("cardholder_name").notNull(),
  balance: decimal("balance", { precision: 10, scale: 2 }).notNull().default('0.00'),
  cardLimit: decimal("card_limit", { precision: 10, scale: 2 }).notNull(),
  status: cardStatusEnum("status").notNull().default('active'),
  gpayCardId: text("gpay_card_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Transactions table
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  cardId: varchar("card_id"),
  type: transactionTypeEnum("type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  balanceBefore: decimal("balance_before", { precision: 10, scale: 2 }).notNull(),
  balanceAfter: decimal("balance_after", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Referrals table
export const referrals = pgTable("referrals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  referrerId: varchar("referrer_id").notNull(),
  referredUserId: varchar("referred_user_id").notNull(),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 4 }).notNull().default('0.0010'), // 0.1%
  totalCommissionEarned: decimal("total_commission_earned", { precision: 10, scale: 2 }).notNull().default('0.00'),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  deposits: many(deposits),
  cards: many(cards),
  transactions: many(transactions),
  referralsGiven: many(referrals, { relationName: "referrer" }),
  referral: one(referrals, {
    fields: [users.id],
    references: [referrals.referredUserId],
    relationName: "referred"
  }),
}));

export const depositsRelations = relations(deposits, ({ one }) => ({
  user: one(users, {
    fields: [deposits.userId],
    references: [users.id],
  }),
}));

export const cardsRelations = relations(cards, ({ one, many }) => ({
  user: one(users, {
    fields: [cards.userId],
    references: [users.id],
  }),
  transactions: many(transactions),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
  card: one(cards, {
    fields: [transactions.cardId],
    references: [cards.id],
  }),
}));

export const referralsRelations = relations(referrals, ({ one }) => ({
  referrer: one(users, {
    fields: [referrals.referrerId],
    references: [users.id],
    relationName: "referrer"
  }),
  referredUser: one(users, {
    fields: [referrals.referredUserId],
    references: [users.id],
    relationName: "referred"
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  balance: true,
  referralCode: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  email: z.string().email(),
  password: z.string().min(8).regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, "Password must contain uppercase, lowercase, and number"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export const loginSchema = z.object({
  emailOrUsername: z.string().min(1, "Email or username is required"),
  password: z.string().min(1, "Password is required"),
});

export const insertDepositSchema = createInsertSchema(deposits).omit({
  id: true,
  userId: true,
  exactAmount: true,
  walletAddress: true,
  status: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  amount: z.number().min(10, "Minimum deposit is $10"),
});

export const insertCardSchema = createInsertSchema(cards).omit({
  id: true,
  userId: true,
  cardNumber: true,
  expiryMonth: true,
  expiryYear: true,
  cvv: true,
  balance: true,
  gpayCardId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  cardLimit: z.number().min(100, "Minimum card limit is $100"),
});

export const cardTopupSchema = z.object({
  cardId: z.string().min(1, "Card ID is required"),
  amount: z.number().min(1, "Amount must be positive"),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginCredentials = z.infer<typeof loginSchema>;
export type InsertDeposit = z.infer<typeof insertDepositSchema>;
export type InsertCard = z.infer<typeof insertCardSchema>;
export type CardTopup = z.infer<typeof cardTopupSchema>;

export type User = typeof users.$inferSelect;
export type Deposit = typeof deposits.$inferSelect;
export type Card = typeof cards.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type Referral = typeof referrals.$inferSelect;

export type UserWithStats = User & {
  totalEarnings?: string;
  referralCount?: number;
  activeCards?: number;
};
